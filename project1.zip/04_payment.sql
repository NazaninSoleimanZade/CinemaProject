USE [cinema];
GO

-- Filtered indexes require QUOTED_IDENTIFIER ON
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

-- =====================================================================
-- Simulated payment gateway: schema upgrade
--
--   * Fresh database :  00_reset -> 01_schema -> 02_seed -> 04_payment
--   * Existing database: just run this script (it never drops anything and it is
--     safe to run again; every step checks first whether it is already done).
--
-- What it adds
--   Payment.Reference      unique, human-readable transaction reference (SIM-..., CASH-...)
--   Payment.CompletedDate  when the payment became Paid / Failed (NULL while Pending)
--   Payment.FailureReason  why it failed (SIMULATED_... codes, never a real bank's answer)
--   UX_Ticket_Payment      one Payment belongs to at most one Ticket
--   CK_Ticket_StateNeedsPayment   a Paid / Pending ticket must have a Payment
-- =====================================================================

-------------------------------------------------------------------------
-- 1) New columns (NULL first, so rows that already exist stay valid)
-------------------------------------------------------------------------
IF COL_LENGTH(N'dbo.Payment', N'Reference') IS NULL
    ALTER TABLE dbo.Payment ADD Reference NVARCHAR(40) NULL;
GO
IF COL_LENGTH(N'dbo.Payment', N'CompletedDate') IS NULL
    ALTER TABLE dbo.Payment ADD CompletedDate DATETIME2 NULL;
GO
IF COL_LENGTH(N'dbo.Payment', N'FailureReason') IS NULL
    ALTER TABLE dbo.Payment ADD FailureReason NVARCHAR(100) NULL;
GO

-------------------------------------------------------------------------
-- 2) Fill the new columns for payments that already exist (seed data etc.)
-------------------------------------------------------------------------
UPDATE dbo.Payment
   SET Reference = N'SEED-' + CAST(PaymentID AS NVARCHAR(20))
 WHERE Reference IS NULL;

UPDATE dbo.Payment
   SET CompletedDate = PaymentDate
 WHERE PaymentStatus <> N'Pending' AND CompletedDate IS NULL;

UPDATE dbo.Payment
   SET FailureReason = N'SEED_DATA'
 WHERE PaymentStatus = N'Failed' AND FailureReason IS NULL;
GO

-------------------------------------------------------------------------
-- 3) Constraints on Payment
-------------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM sys.columns
           WHERE object_id = OBJECT_ID(N'dbo.Payment') AND name = N'Reference' AND is_nullable = 1)
    ALTER TABLE dbo.Payment ALTER COLUMN Reference NVARCHAR(40) NOT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'UX_Payment_Reference' AND object_id = OBJECT_ID(N'dbo.Payment'))
    CREATE UNIQUE INDEX UX_Payment_Reference ON dbo.Payment (Reference);
GO

-- Pending has no completion time; Paid / Failed always have one
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Payment_Completed')
    ALTER TABLE dbo.Payment ADD CONSTRAINT CK_Payment_Completed CHECK (
        (PaymentStatus = N'Pending'  AND CompletedDate IS NULL) OR
        (PaymentStatus <> N'Pending' AND CompletedDate IS NOT NULL));
GO

-- A failure reason only makes sense on a Failed payment
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Payment_FailureReason')
    ALTER TABLE dbo.Payment ADD CONSTRAINT CK_Payment_FailureReason CHECK (
        PaymentStatus = N'Failed' OR FailureReason IS NULL);
GO

-------------------------------------------------------------------------
-- 4) Constraints on Ticket (skipped with a warning if old data would break them)
-------------------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'UX_Ticket_Payment' AND object_id = OBJECT_ID(N'dbo.Ticket'))
BEGIN
    IF EXISTS (SELECT PaymentID FROM dbo.Ticket WHERE PaymentID IS NOT NULL
               GROUP BY PaymentID HAVING COUNT(*) > 1)
        PRINT N'WARNING: UX_Ticket_Payment skipped - some Payment is used by more than one Ticket. Fix those rows and run this script again.';
    ELSE
        CREATE UNIQUE INDEX UX_Ticket_Payment ON dbo.Ticket (PaymentID) WHERE PaymentID IS NOT NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Ticket_StateNeedsPayment')
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Ticket
               WHERE TicketStatus IN (N'Paid', N'Pending') AND PaymentID IS NULL)
        PRINT N'WARNING: CK_Ticket_StateNeedsPayment skipped - some Paid/Pending tickets have no Payment. Fix those rows and run this script again.';
    ELSE
        ALTER TABLE dbo.Ticket ADD CONSTRAINT CK_Ticket_StateNeedsPayment CHECK (
            TicketStatus NOT IN (N'Paid', N'Pending') OR PaymentID IS NOT NULL);
END
GO

PRINT N'04_payment.sql finished.';
GO
