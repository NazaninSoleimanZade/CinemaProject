# CinemaOnline

A cinema ticket booking web app (university project). Flask + Microsoft SQL Server.

## Features
- Browse movies, search by title, filter by genre
- Register / log in (passwords are stored as Werkzeug hashes)
- Book a seat for a showtime (only showtimes that have not started yet); double booking is blocked both in the app and by a unique index in the database
- Ticket page for every booking (`/ticket/<id>`), "My Tickets" list, cancel an unpaid reservation, printable ticket
- **Simulated online payment** (no real money, no card data): the server randomly decides success or failure, see "Payment simulation" below
- Staff / Admin dashboard: counts by status, paginated bookings, "Mark paid" button for cash payments, CSV export of **all** bookings (full ticket numbers; the page reloads itself every 60 seconds)

## Requirements
- Python 3.9+
- SQL Server 2017 or newer (the app uses `STRING_AGG`) with Windows authentication
- ODBC Driver 17 or 18 for SQL Server
- `pip install -r requirements.txt`

## Setup
1. In SQL Server Management Studio create an empty database named `cinema`
   (`CREATE DATABASE cinema;`).
2. Run the scripts from the `database` folder **in this order**:
   - `00_reset.sql` – deletes all tables and data (skip it on a brand-new database)
   - `01_schema.sql` – creates the tables, constraints and indexes
   - `02_seed.sql` – demo cinemas, movies, 30 days of showtimes, seats, users, tickets
   - `04_payment.sql` – adds the payment-simulation columns and constraints. Run it **after** `02_seed.sql`
     (fresh database), or on its own on an existing database. Safe to run more than once.
   - `03_demo_queries.sql` – optional read-only example queries
3. Check the connection: `python test_db.py`
4. Start the app: `python app.py`, then open http://localhost:5000

### Connection settings (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `DB_SERVER` | `localhost` | SQL Server instance, e.g. `.\SQLEXPRESS` |
| `DB_NAME` | `cinema` | database name |
| `DB_DRIVER` | newest installed of 18 / 17 | ODBC driver name |
| `SECRET_KEY` | random at start-up | Flask session key. If unset, a random key is generated and everybody is logged out whenever the app restarts. Set your own for a stable key (needed when several processes serve the site) |
| `FLASK_DEBUG` | off | set to `1` to enable debug mode and `/debug/db-test` |
| `SESSION_COOKIE_SECURE` | off | set to `1` when the site is served over HTTPS |
| `PAYMENT_SIMULATION` | on | set to `0` to switch online payment off |
| `PAYMENT_FAILURE_RATE` | `0.15` | chance (0-1) that a **simulated** payment fails. A demo setting, not a real-world statistic |
| `PAYMENT_PENDING_TIMEOUT_MINUTES` | `10` | a payment still Pending after this long is cancelled automatically |
| `MAX_OPEN_RESERVATIONS` | `6` | most unpaid (Reserved/Pending) tickets one customer can hold for upcoming shows |
| `LOGIN_MAX_FAILURES` / `LOGIN_WINDOW_SECONDS` | `5` / `300` | failed logins allowed per (IP, username) in that window |

Example (Windows cmd): `set DB_SERVER=.\SQLEXPRESS` and then `python app.py`.

## Accounts
- Anyone can register; self-registration always creates a **Customer**.
- Staff, Admin and Operator accounts are created in the database. To make an
  existing account a staff member:
  ```sql
  UPDATE dbo.[User] SET Role = N'Staff' WHERE Username = N'your_username';
  ```
  Staff and Admin can open the dashboard and use "Mark paid" / the CSV export.
- The seeded users (`admin01`, `cashier01`, `operator01`, `user01`) have hashed passwords.
  To set a known password, create a hash and update the row:
  ```
  python -c "from werkzeug.security import generate_password_hash as g; print(g('NewPass123'))"
  ```
  ```sql
  UPDATE dbo.[User] SET [Password] = N'<paste hash>' WHERE Username = N'user01';
  ```

## Database
Tables: Cinema, Hall, Seat, Movie, [Session] (a showtime), [User], Ticket, Payment,
MovieGenre, MovieActor, MovieLanguage, PaymentMethod. (`Payment` and `PaymentMethod` are used by the
payment simulation and the cashier's "Mark paid".)

- A seat is held by every ticket that is not `Failed` (`UX_Ticket_ActiveSeat`, a filtered unique index).
- Ticket status: `Reserved`, `Paid`, `Pending`, `Failed`. Booking through the site creates `Reserved` tickets (pay online with the simulation, or at the cinema).
- The ticket number shown to the customer is a random UUID. It is stored in the `QRCode` column of `Ticket` (a legacy column name; no QR image is generated).

## Payment simulation
**This is a simulation for a development / academic project. It is not connected to any bank or payment
provider, and a "failed" payment is just a random number, not a bank's decision. Never type or store real
card numbers.**

```
Ticket:   Reserved --pay--> Pending --> Paid
                                   \--> Failed   (the seat becomes free again)
          Reserved --cashier "Mark paid"--> Paid
          Reserved --customer cancels--> Failed
Payment:  Pending --> Paid | Failed      (Paid / Failed never change again)
```
- The browser only sends the ticket id. The amount is read from the showtime's price in the database and the
  result is chosen on the server (`payments.py`). Nothing the browser says can mark a ticket as paid.
- Starting a payment is one database transaction in which only one request can win
  (`UPDATE ... WHERE TicketStatus = 'Reserved'`), so double clicks and refreshes cannot create two payments.
- The final result of Payment and Ticket is written in one transaction. A payment left `Pending` (for example the
  server crashed) is cancelled automatically after `PAYMENT_PENDING_TIMEOUT_MINUTES`.
- Consistency check (should return no rows):
  ```sql
  SELECT t.QRCode FROM dbo.Ticket t JOIN dbo.Payment p ON p.PaymentID = t.PaymentID
  WHERE (t.TicketStatus = N'Paid'    AND p.PaymentStatus <> N'Paid')
     OR (t.TicketStatus = N'Pending' AND p.PaymentStatus <> N'Pending')
     OR (p.PaymentStatus = N'Paid'   AND t.TicketStatus  <> N'Paid');
  ```

## Tests
```
pip install pytest
python -m pytest tests/test_unit.py            # no database needed
```
`tests/test_payments_db.py` needs a **separate** SQL Server database (never your real one): create `cinema_test`
with `00_reset.sql` + `01_schema.sql` + `04_payment.sql` (edit the `USE` line), then
`set DB_NAME=cinema_test`, `set CINEMA_TEST_DB=1` and run `python -m pytest tests/test_payments_db.py`.

## Project layout
```
app.py                 Flask routes, validation, CSRF, login throttling
database.py            connection settings + db() helper (the only place that knows the connection)
payments.py            simulated payment gateway (kept separate from the routes)
test_db.py             standalone connection test
requirements.txt
database/              SQL scripts (00 reset, 01 schema, 02 seed, 03 demo queries, 04 payment)
templates/             base, index, login, register, ticket, my_tickets, payment_result, dashboard, error
static/css/style.css   styles (UTF-8)
static/js/main.js      shared JavaScript
tests/                 pytest tests (see "Tests")
```
