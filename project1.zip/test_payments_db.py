"""Integration tests against a REAL SQL Server database.   NOT RUN by the author.

These tests write to the database, so they only run when
  * CINEMA_TEST_DB=1  is set, and
  * DB_NAME contains the word "test"   (they refuse to touch a database called "cinema").

Prepare once (SSMS):  CREATE DATABASE cinema_test;  then run, with `USE [cinema_test]` at the
top of each script:  00_reset.sql, 01_schema.sql, 04_payment.sql   (02_seed.sql is not needed).
Run (Windows cmd):
    set DB_NAME=cinema_test
    set CINEMA_TEST_DB=1
    python -m pytest tests/test_payments_db.py

Every test creates its own cinema / movie / showtimes / users and removes them afterwards.
"""
import os
import threading
import uuid
from datetime import date, timedelta
from decimal import Decimal

import pyodbc
import pytest

import database
import payments
from conftest import TOKEN, flashes, login_as, post

pytestmark = pytest.mark.skipif(
    os.environ.get('CINEMA_TEST_DB') != '1' or 'test' not in os.environ.get('DB_NAME', '').lower(),
    reason='set CINEMA_TEST_DB=1 and DB_NAME=<a database with "test" in its name> to run these tests')

TOMORROW = date.today() + timedelta(days=1)
YESTERDAY = date.today() - timedelta(days=1)


class World:
    """A tiny cinema created for one test."""

    def __init__(self, conn):
        self.conn = conn
        c = conn.cursor()
        tag = uuid.uuid4().hex[:8]
        self.user, self.other = f'test_{tag}', f'test_o_{tag}'
        c.execute("INSERT INTO Cinema (CinemaName, Phone1, Province, City) OUTPUT INSERTED.CinemaID "
                  "VALUES (?, ?, 'T', 'T')", (f'Test {tag}', '0' + str(uuid.uuid4().int)[:10]))
        self.cinema = c.fetchall()[0][0]
        c.execute("INSERT INTO Movie (ImdbID, Title, ReleaseYear, ReleaseMonth, ReleaseDay, DurationMin) "
                  "OUTPUT INSERTED.FilmID VALUES (?, ?, 2020, 1, 1, 100)", (f'tt{tag}', f'Test film {tag}'))
        self.film = c.fetchall()[0][0]
        c.execute("INSERT INTO Hall (CinemaID, HallNumber, Capacity) VALUES (?, 1, 4)", (self.cinema,))
        for seat in range(1, 5):
            c.execute("INSERT INTO Seat (CinemaID, HallNumber, RowNo, SeatNo, SeatType) VALUES (?, 1, 1, ?, 'Normal')",
                      (self.cinema, seat))
        for day, price in ((TOMORROW, 150000), (YESTERDAY, 100000)):
            c.execute("INSERT INTO [Session] (CinemaID, HallNumber, ShowDate, StartTime, EndTime, FilmID, Price) "
                      "VALUES (?, 1, ?, '18:00:00', '20:00:00', ?, ?)", (self.cinema, day, self.film, price))
        for name in (self.user, self.other):
            c.execute("INSERT INTO [User] (Username, [Password], Role, FirstName, LastName) "
                      "VALUES (?, 'x', 'Customer', 'T', 'U')", (name,))
        conn.commit()

    def ticket(self, seat=1, past=False, username=None):
        tid = str(uuid.uuid4())
        self.conn.cursor().execute(
            "INSERT INTO Ticket (QRCode, Username, CinemaID, HallNumber, ShowDate, StartTime, RowNo, SeatNo, TicketStatus) "
            "VALUES (?, ?, ?, 1, ?, '18:00:00', 1, ?, 'Reserved')",
            (tid, username or self.user, self.cinema, YESTERDAY if past else TOMORROW, seat))
        self.conn.commit()
        return tid

    def one(self, sql, *params):
        c = self.conn.cursor()
        c.execute(sql, params)
        return c.fetchone()

    def status(self, tid):
        return self.one("SELECT TicketStatus FROM Ticket WHERE QRCode = ?", tid)[0]

    def payment(self, pid):
        return self.one("SELECT PaymentStatus, Amount, CompletedDate, FailureReason, Reference "
                        "FROM Payment WHERE PaymentID = ?", pid)

    def methods(self, pid):
        c = self.conn.cursor()
        c.execute("SELECT MethodType FROM PaymentMethod WHERE PaymentID = ?", (pid,))
        return [r[0] for r in c.fetchall()]

    def payment_count(self):
        return self.one("SELECT COUNT(*) FROM Payment")[0]

    def audit(self):
        """Tickets whose status disagrees with their payment (must always be empty)."""
        c = self.conn.cursor()
        c.execute("""
            SELECT t.QRCode FROM Ticket t JOIN Payment p ON p.PaymentID = t.PaymentID
            WHERE t.Username IN (?, ?) AND (
                   (t.TicketStatus = N'Paid'    AND p.PaymentStatus <> N'Paid')
                OR (t.TicketStatus = N'Pending' AND p.PaymentStatus <> N'Pending')
                OR (p.PaymentStatus = N'Paid'   AND t.TicketStatus  <> N'Paid'))
        """, (self.user, self.other))
        return c.fetchall()

    def cleanup(self):
        c = self.conn.cursor()
        self.conn.rollback()
        c.execute("SELECT PaymentID FROM Ticket WHERE Username IN (?, ?) AND PaymentID IS NOT NULL",
                  (self.user, self.other))
        payment_ids = [r[0] for r in c.fetchall()]
        c.execute("DELETE FROM Ticket WHERE Username IN (?, ?)", (self.user, self.other))
        for pid in payment_ids:
            c.execute("DELETE FROM Payment WHERE PaymentID = ?", (pid,))
        c.execute("DELETE FROM [Session] WHERE CinemaID = ?", (self.cinema,))
        c.execute("DELETE FROM Movie WHERE FilmID = ?", (self.film,))
        c.execute("DELETE FROM Cinema WHERE CinemaID = ?", (self.cinema,))
        c.execute("DELETE FROM [User] WHERE Username IN (?, ?)", (self.user, self.other))
        self.conn.commit()


@pytest.fixture
def world():
    conn = database.get_db_connection()
    assert conn is not None, 'cannot connect to the test database'
    w = World(conn)
    try:
        yield w
    finally:
        w.cleanup()
        conn.close()


# --------------------------------------------------------------------- the payment functions

def test_paid_flow_keeps_payment_and_ticket_consistent(world):
    tid = world.ticket()
    pid, reference = payments.start_payment(world.conn, tid, world.user)
    assert world.status(tid) == 'Pending' and world.payment(pid).PaymentStatus == 'Pending'
    payments.finish_payment(world.conn, pid, tid, 'Paid')
    p = world.payment(pid)
    assert world.status(tid) == 'Paid' and p.PaymentStatus == 'Paid'
    assert p.CompletedDate is not None and p.FailureReason is None and p.Reference == reference
    assert p.Amount == Decimal('150000.00')
    assert world.methods(pid) == ['SimulatedGateway']
    assert world.audit() == []


def test_failed_flow_releases_the_seat(world):
    tid = world.ticket(seat=1)
    pid, _ = payments.start_payment(world.conn, tid, world.user)
    payments.finish_payment(world.conn, pid, tid, 'Failed', 'SIMULATED_DECLINE')
    p = world.payment(pid)
    assert world.status(tid) == 'Failed' and p.PaymentStatus == 'Failed' and p.FailureReason == 'SIMULATED_DECLINE'
    assert world.methods(pid) == []
    world.ticket(seat=1, username=world.other)          # the same seat can be booked again (no IntegrityError)
    assert world.audit() == []


def test_second_start_creates_no_second_payment(world):
    tid = world.ticket()
    before = world.payment_count()
    assert payments.start_payment(world.conn, tid, world.user) is not None
    assert payments.start_payment(world.conn, tid, world.user) is None
    assert world.payment_count() == before + 1


def test_two_simultaneous_starts_have_exactly_one_winner(world):
    tid = world.ticket()
    before = world.payment_count()
    results, barrier = [], threading.Barrier(2)

    def attempt():
        conn = database.get_db_connection()
        try:
            barrier.wait()
            results.append(payments.start_payment(conn, tid, world.user))
        finally:
            conn.close()

    threads = [threading.Thread(target=attempt) for _ in range(2)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert sorted(r is None for r in results) == [False, True]
    assert world.payment_count() == before + 1


def test_cannot_pay_someone_elses_ticket(world):
    tid = world.ticket()
    assert payments.start_payment(world.conn, tid, world.other) is None
    assert world.status(tid) == 'Reserved'


def test_cannot_pay_when_the_show_has_started(world):
    tid = world.ticket(past=True)
    assert payments.start_payment(world.conn, tid, world.user) is None
    assert world.status(tid) == 'Reserved'


def test_amount_is_the_current_showtime_price(world):
    tid = world.ticket()
    world.conn.cursor().execute("UPDATE [Session] SET Price = 175000 WHERE CinemaID = ? AND ShowDate = ?",
                                (world.cinema, TOMORROW))
    world.conn.commit()
    pid, _ = payments.start_payment(world.conn, tid, world.user)
    assert world.payment(pid).Amount == Decimal('175000.00')


def test_finish_twice_is_refused_and_changes_nothing(world):
    tid = world.ticket()
    pid, _ = payments.start_payment(world.conn, tid, world.user)
    payments.finish_payment(world.conn, pid, tid, 'Paid')
    with pytest.raises(RuntimeError):
        payments.finish_payment(world.conn, pid, tid, 'Failed', 'SIMULATED_DECLINE')
    assert world.status(tid) == 'Paid' and world.payment(pid).PaymentStatus == 'Paid'


def test_stale_pending_payment_is_expired_and_fresh_one_is_not(world):
    old, fresh = world.ticket(seat=1), world.ticket(seat=2)
    old_pid, _ = payments.start_payment(world.conn, old, world.user)
    fresh_pid, _ = payments.start_payment(world.conn, fresh, world.user)
    world.conn.cursor().execute("UPDATE Payment SET PaymentDate = DATEADD(HOUR, -1, SYSDATETIME()) WHERE PaymentID = ?",
                                (old_pid,))
    world.conn.commit()
    assert payments.expire_stale_pending(world.conn, minutes=10) >= 1
    assert world.status(old) == 'Failed' and world.payment(old_pid).FailureReason == 'PENDING_EXPIRED'
    assert world.status(fresh) == 'Pending' and world.payment(fresh_pid).PaymentStatus == 'Pending'
    assert world.audit() == []


def test_cashier_marks_paid_once(world):
    tid = world.ticket()
    reference = payments.mark_paid_cash(world.conn, tid)
    assert reference.startswith('CASH-') and world.status(tid) == 'Paid'
    pid = world.one("SELECT PaymentID FROM Ticket WHERE QRCode = ?", tid)[0]
    assert world.methods(pid) == ['Cash'] and world.payment(pid).PaymentStatus == 'Paid'
    assert payments.mark_paid_cash(world.conn, tid) is None
    assert world.audit() == []


# --------------------------------------------------------------------- database constraints (04_payment.sql)

def test_database_refuses_a_paid_ticket_without_payment(world):
    tid = world.ticket()
    with pytest.raises(pyodbc.IntegrityError):
        world.conn.cursor().execute("UPDATE Ticket SET TicketStatus = 'Paid' WHERE QRCode = ?", (tid,))
    world.conn.rollback()


def test_database_refuses_one_payment_for_two_tickets(world):
    t1, t2 = world.ticket(seat=1), world.ticket(seat=2)
    pid, _ = payments.start_payment(world.conn, t1, world.user)
    with pytest.raises(pyodbc.IntegrityError):
        world.conn.cursor().execute("UPDATE Ticket SET TicketStatus = 'Pending', PaymentID = ? WHERE QRCode = ?",
                                    (pid, t2))
    world.conn.rollback()


def test_database_refuses_inconsistent_payment_rows(world):
    c = world.conn.cursor()
    with pytest.raises(pyodbc.IntegrityError):         # Paid without CompletedDate
        c.execute("INSERT INTO Payment (Amount, PaymentStatus, Reference) VALUES (1, 'Paid', ?)", (uuid.uuid4().hex[:20],))
    world.conn.rollback()
    with pytest.raises(pyodbc.IntegrityError):         # failure reason on a Pending payment
        c.execute("INSERT INTO Payment (Amount, PaymentStatus, Reference, FailureReason) VALUES (1, 'Pending', ?, 'X')",
                  (uuid.uuid4().hex[:20],))
    world.conn.rollback()


# --------------------------------------------------------------------- through the web routes

def _web_client(app_module, world):
    client = app_module.app.test_client()
    login_as(client, username=world.user)
    return client


def test_web_pay_twice_creates_one_payment_and_a_paid_ticket(world, app_module, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '0')
    tid = world.ticket()
    client = _web_client(app_module, world)
    before = world.payment_count()
    first = post(client, f'/pay/{tid}')
    assert first.status_code == 302 and '/payment/SIM-' in first.headers['Location']
    second = post(client, f'/pay/{tid}')                               # refresh / second click
    assert 'cannot be paid now' in flashes(client)[-1] and second.headers['Location'].endswith(f'/ticket/{tid}')
    assert world.status(tid) == 'Paid' and world.payment_count() == before + 1
    page = client.get(first.headers['Location'])
    assert page.status_code == 200 and 'Payment successful' in page.get_data(as_text=True)


def test_web_failed_payment_shows_explanation_and_frees_the_seat(world, app_module, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '1')
    tid = world.ticket(seat=3)
    client = _web_client(app_module, world)
    resp = post(client, f'/pay/{tid}')
    html = client.get(resp.headers['Location']).get_data(as_text=True)
    assert 'Payment failed' in html and 'seat has been released' in html
    assert world.status(tid) == 'Failed'
    world.ticket(seat=3, username=world.other)


def test_web_booking_then_refresh_and_started_show(world, app_module):
    client = _web_client(app_module, world)
    form = {'cinema_id': world.cinema, 'hall_number': 1, 'show_date': TOMORROW.isoformat(),
            'start_time': '18:00:00', 'row_no': 1, 'seat_no': 2}
    first = post(client, '/book', form)
    assert first.status_code == 302 and '/ticket/' in first.headers['Location']          # Post/Redirect/Get
    assert client.get(first.headers['Location']).status_code == 200                      # refreshing is harmless
    post(client, '/book', form)                                                          # same seat again
    assert 'already taken' in flashes(client)[-1]
    post(client, '/book', {**form, 'show_date': YESTERDAY.isoformat(), 'seat_no': 3})    # show already started
    assert 'already started' in flashes(client)[-1]
