"""Unit tests that run WITHOUT SQL Server:   python -m pytest tests/test_unit.py"""
import json
from datetime import date, datetime, time
from decimal import Decimal

import pyodbc
import pytest
from werkzeug.security import generate_password_hash

import payments
from conftest import TOKEN, flashes, guest_token, login_as, post, row

TICKET_ID = '11111111-2222-3333-4444-555555555555'


# ===================================================================== payments.py (pure logic)

class FixedRng:
    def __init__(self, value):
        self.value = value

    def random(self):
        return self.value

    def choice(self, items):
        return items[0]


@pytest.mark.parametrize('raw, expected', [
    (None, 0.15), ('0', 0.0), ('1', 1.0), ('0.3', 0.3), ('5', 1.0), ('-2', 0.0),
    ('abc', 0.15), ('nan', 0.15), ('', 0.15),
])
def test_failure_rate_parsing_and_clamping(monkeypatch, raw, expected):
    if raw is None:
        monkeypatch.delenv('PAYMENT_FAILURE_RATE', raising=False)
    else:
        monkeypatch.setenv('PAYMENT_FAILURE_RATE', raw)
    assert payments.failure_rate() == expected


def test_rate_zero_always_paid_and_rate_one_always_failed(monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '0')
    assert all(payments.simulate_outcome() == ('Paid', None) for _ in range(200))
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '1')
    for _ in range(200):
        outcome, reason = payments.simulate_outcome()
        assert outcome == 'Failed' and reason in payments.FAILURE_REASONS
        assert reason.startswith('SIMULATED_')


def test_outcome_uses_the_injected_random_number(monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '0.15')
    assert payments.simulate_outcome(FixedRng(0.14))[0] == 'Failed'     # below the rate
    assert payments.simulate_outcome(FixedRng(0.15))[0] == 'Paid'       # not below
    assert payments.simulate_outcome(FixedRng(0.99)) == ('Paid', None)


def test_failure_messages():
    assert 'declined' in payments.failure_message('SIMULATED_DECLINE')
    assert 'automatically' in payments.failure_message('PENDING_EXPIRED')
    assert payments.failure_message(None) == 'The payment did not complete.'
    assert payments.failure_message('SOMETHING_NEW') == 'The payment did not complete.'


def test_pending_timeout_setting(monkeypatch):
    monkeypatch.setenv('PAYMENT_PENDING_TIMEOUT_MINUTES', '3')
    assert payments.pending_timeout_minutes() == 3
    for bad in ('0', '-4', 'x'):
        monkeypatch.setenv('PAYMENT_PENDING_TIMEOUT_MINUTES', bad)
        assert payments.pending_timeout_minutes() == payments.DEFAULT_PENDING_TIMEOUT_MINUTES


# ===================================================================== payments.py with a fake connection

def test_start_payment_happy_path(fake_db):
    fake_db.on("SELECT S.Price FROM Ticket T", [(Decimal('150000.00'),)])
    fake_db.on("INSERT INTO Payment", [(5,)])
    payment_id, reference = payments.start_payment(fake_db, TICKET_ID, 'user01')
    assert payment_id == 5 and reference.startswith('SIM-')
    insert = fake_db.sql_containing('INSERT INTO Payment')[0]
    assert insert[1][0] == Decimal('150000.00')            # amount comes from the database row
    claim = fake_db.sql_containing("SET TicketStatus = 'Pending'")[0]
    assert claim[1] == (5, TICKET_ID, 'user01')
    assert fake_db.commits == 1 and fake_db.rollbacks == 0


def test_start_payment_refuses_ticket_that_is_not_payable(fake_db):
    # the SELECT finds nothing: not yours / not Reserved / already has a payment / show started
    assert payments.start_payment(fake_db, TICKET_ID, 'someone_else') is None
    assert not fake_db.sql_containing('INSERT INTO Payment')
    assert fake_db.commits == 0


def test_start_payment_loses_the_race(fake_db):
    fake_db.on("SELECT S.Price FROM Ticket T", [(Decimal('1000'),)])
    fake_db.on("INSERT INTO Payment", [(9,)])
    fake_db.on("SET TicketStatus = 'Pending'", rowcount=0)   # another request claimed it first
    assert payments.start_payment(fake_db, TICKET_ID, 'user01') is None
    assert fake_db.rollbacks >= 1 and fake_db.commits == 0   # the new Payment row is rolled back


def test_start_payment_checks_that_the_show_has_not_started(fake_db):
    payments.start_payment(fake_db, TICKET_ID, 'user01')
    select = fake_db.sql_containing('SELECT S.Price')[0][0]
    assert 'GETDATE()' in select and "TicketStatus = 'Reserved'" in select and 'PaymentID IS NULL' in select


def test_finish_payment_paid_updates_payment_ticket_and_method(fake_db):
    payments.finish_payment(fake_db, 5, TICKET_ID, 'Paid', None)
    pay = fake_db.sql_containing('UPDATE Payment')[0]
    assert pay[1] == ('Paid', None, 5)
    assert fake_db.sql_containing('UPDATE Ticket')[0][1] == ('Paid', TICKET_ID, 5)
    assert fake_db.sql_containing("INSERT INTO PaymentMethod")[0][1] == (5,)
    assert fake_db.commits == 1


def test_finish_payment_failed_does_not_touch_paid_state(fake_db):
    payments.finish_payment(fake_db, 5, TICKET_ID, 'Failed', 'SIMULATED_DECLINE')
    assert fake_db.sql_containing('UPDATE Payment')[0][1] == ('Failed', 'SIMULATED_DECLINE', 5)
    assert fake_db.sql_containing('UPDATE Ticket')[0][1] == ('Failed', TICKET_ID, 5)
    assert not fake_db.sql_containing('INSERT INTO PaymentMethod')
    assert not any("'Paid'" in s for s, _ in fake_db.executed)   # nothing can mark it Paid


def test_finish_payment_ignores_reason_for_paid(fake_db):
    payments.finish_payment(fake_db, 5, TICKET_ID, 'Paid', 'SIMULATED_DECLINE')
    assert fake_db.sql_containing('UPDATE Payment')[0][1] == ('Paid', None, 5)


@pytest.mark.parametrize('needle', ['UPDATE Payment', 'UPDATE Ticket'])
def test_finish_payment_rolls_back_when_state_already_changed(fake_db, needle):
    fake_db.on(needle, rowcount=0)
    with pytest.raises(RuntimeError):
        payments.finish_payment(fake_db, 5, TICKET_ID, 'Paid', None)
    assert fake_db.rollbacks == 1 and fake_db.commits == 0
    assert not fake_db.sql_containing('INSERT INTO PaymentMethod')


def test_finish_payment_rejects_unknown_outcome(fake_db):
    with pytest.raises(ValueError):
        payments.finish_payment(fake_db, 5, TICKET_ID, 'Refunded')
    assert not fake_db.executed


def test_mark_paid_cash(fake_db):
    fake_db.on("SELECT S.Price FROM Ticket T", [(Decimal('120000'),)])
    fake_db.on("INSERT INTO Payment", [(8,)])
    reference = payments.mark_paid_cash(fake_db, TICKET_ID)
    assert reference.startswith('CASH-')
    assert fake_db.sql_containing("INSERT INTO PaymentMethod")[0][0].endswith("'Cash')")
    assert fake_db.sql_containing("SET TicketStatus = 'Paid', PaymentID = ?")[0][1] == (8, TICKET_ID)


def test_mark_paid_cash_refuses_non_reserved_ticket(fake_db):
    assert payments.mark_paid_cash(fake_db, TICKET_ID) is None
    assert not fake_db.sql_containing('INSERT INTO Payment')


def test_expire_stale_pending(fake_db):
    fake_db.on("UPDATE Payment", rowcount=2)
    assert payments.expire_stale_pending(fake_db, minutes=10) == 2
    update = fake_db.sql_containing('UPDATE Payment')[0]
    assert update[1] == (-10,) and 'PENDING_EXPIRED' in update[0]
    assert "SET T.TicketStatus = 'Failed'" in fake_db.sql_containing('UPDATE T')[0][0]
    assert fake_db.commits == 1


# ===================================================================== CSRF and access control

def test_post_without_csrf_token_is_rejected(client, fake_db):
    guest_token(client)
    resp = client.post('/login', data={'username': 'a', 'password': 'b'})
    assert resp.status_code == 400
    assert not fake_db.executed


def test_post_with_wrong_csrf_token_is_rejected(client):
    guest_token(client)
    assert client.post('/login', data={'username': 'a', 'password': 'b', 'csrf_token': 'nope'}).status_code == 400
    assert client.post('/login', data={'username': 'a', 'password': 'b', 'csrf_token': 'ü'}).status_code == 400


def test_post_without_any_session_is_rejected(client):
    assert client.post('/book', data={}).status_code == 400


def test_every_post_route_needs_the_token(client):
    login_as(client, role='Admin')
    for url in ('/book', '/pay/x', '/ticket/x/cancel', '/staff/ticket/x/mark_paid', '/logout',
                '/register', '/login'):
        assert client.post(url, data={}).status_code == 400, url


def test_forms_contain_the_token(client, fake_db):
    guest_token(client)
    for url in ('/login_page', '/register_page'):
        assert f'value="{TOKEN}"' in client.get(url).get_data(as_text=True)


def test_logout_is_post_only_and_clears_session(client):
    login_as(client)
    assert client.get('/logout').status_code == 405
    resp = post(client, '/logout')
    assert resp.status_code == 302
    with client.session_transaction() as s:
        assert 'username' not in s


def test_pages_that_need_login_redirect_guests(client, fake_db):
    for url in ('/my_tickets', '/ticket/x', f'/payment/SIM-1'):
        resp = client.get(url)
        assert resp.status_code == 302 and '/login_page' in resp.headers['Location'], url
    assert not fake_db.executed


@pytest.mark.parametrize('role', [None, 'Customer', 'Operator'])
def test_dashboard_and_export_are_staff_only(client, fake_db, role):
    if role:
        login_as(client, role=role)
    for url in ('/dashboard', '/dashboard/export.csv'):
        resp = client.get(url)
        assert resp.status_code == 302 and resp.headers['Location'].endswith('/'), url
    resp = post(client, '/staff/ticket/x/mark_paid') if role else client.post('/staff/ticket/x/mark_paid')
    assert resp.status_code in (302, 400)
    assert not fake_db.executed


def test_unknown_page_shows_error_template(client):
    resp = client.get('/nothing-here')
    assert resp.status_code == 404 and 'Page not found' in resp.get_data(as_text=True)


# ===================================================================== database down

def test_page_shows_503_when_database_is_down(client, monkeypatch):
    import database
    monkeypatch.setattr(database, 'get_db_connection', lambda: None)
    resp = client.get('/')
    assert resp.status_code == 503 and 'Service unavailable' in resp.get_data(as_text=True)


def test_post_redirects_with_message_when_database_is_down(client, monkeypatch):
    import database
    monkeypatch.setattr(database, 'get_db_connection', lambda: None)
    guest_token(client)
    resp = post(client, '/login', {'username': 'a', 'password': 'b'})
    assert resp.status_code == 302 and flashes(client) == ['Database connection error. Please try again later.']


def test_showtimes_api_returns_json_error_when_database_is_down(client, monkeypatch):
    import database
    monkeypatch.setattr(database, 'get_db_connection', lambda: None)
    resp = client.get('/get_showtimes/1')
    assert resp.status_code == 503 and resp.get_json() == {'error': 'Database connection failed'}


def test_connection_is_closed_and_rolled_back_on_error(client, fake_db):
    fake_db.on('SELECT DISTINCT Genre', pyodbc.ProgrammingError('boom'))
    with pytest.raises(pyodbc.ProgrammingError):     # TESTING mode re-raises; production shows the 500 page
        client.get('/')
    assert fake_db.closed and fake_db.rollbacks == 1


# ===================================================================== registration and login

def _register_data(**changes):
    data = {'username': 'newuser', 'password': 'secret1', 'confirm_password': 'secret1',
            'email': '', 'first_name': 'Sara', 'last_name': 'Kazemi'}
    data.update(changes)
    return data


def test_register_always_creates_a_customer_and_stores_empty_email_as_null(client, fake_db):
    guest_token(client)
    resp = post(client, '/register', _register_data(role='Admin'))      # forged "role" is ignored
    assert resp.status_code == 302 and '/login_page' in resp.headers['Location']
    insert = fake_db.sql_containing('INSERT INTO [User]')[0][1]
    assert insert[0] == 'newuser' and insert[2] == 'Customer' and insert[3] is None
    assert insert[1] != 'secret1' and insert[1].startswith(('pbkdf2:', 'scrypt:'))   # hashed


@pytest.mark.parametrize('changes, message', [
    ({'password': 'abc', 'confirm_password': 'abc'}, 'at least 6'),
    ({'confirm_password': 'different'}, 'do not match'),
    ({'username': 'ab'}, 'at least 3'),
    ({'username': 'has space'}, 'no spaces'),
    ({'username': 'x' * 51}, 'too long'),
    ({'last_name': 'x' * 81}, 'too long'),
    ({'email': 'not-an-email'}, 'valid email'),
    ({'first_name': ''}, 'required fields'),
])
def test_register_validation(client, fake_db, changes, message):
    guest_token(client)
    post(client, '/register', _register_data(**changes))
    assert message in ' '.join(flashes(client))
    assert not fake_db.executed                     # rejected before touching the database


def test_register_rejects_existing_username_and_email(client, fake_db):
    guest_token(client)
    fake_db.on('WHERE Username = ?', [('newuser',)])
    post(client, '/register', _register_data())
    assert 'Username already exists' in ' '.join(flashes(client))
    assert not fake_db.sql_containing('INSERT INTO [User]')


def test_register_handles_a_race_between_check_and_insert(client, fake_db):
    guest_token(client)
    fake_db.on('INSERT INTO [User]', pyodbc.IntegrityError('duplicate key'))
    post(client, '/register', _register_data())
    assert 'already exists' in ' '.join(flashes(client)) and fake_db.rollbacks == 1


def test_login_success_uses_the_name_stored_in_the_database(client, fake_db):
    fake_db.on('FROM [User] WHERE Username = ?',
               [('User01', generate_password_hash('secret1'), 'Customer', 'Ali')])
    guest_token(client)
    resp = post(client, '/login', {'username': 'user01', 'password': 'secret1'})   # typed in lower case
    assert resp.status_code == 302
    with client.session_transaction() as s:
        assert s['username'] == 'User01' and s['role'] == 'Customer' and s['first_name'] == 'Ali'


def test_login_wrong_password_and_unknown_user_give_the_same_message(client, fake_db):
    guest_token(client)
    fake_db.on('FROM [User] WHERE Username = ?', [('User01', generate_password_hash('secret1'), 'Customer', 'Ali')])
    post(client, '/login', {'username': 'user01', 'password': 'wrong'})
    fake_db.responses.clear()
    post(client, '/login', {'username': 'ghost', 'password': 'wrong'})
    assert flashes(client) == ['Invalid username or password.'] * 2


def test_login_is_blocked_after_too_many_failures(client, fake_db, app_module):
    guest_token(client)
    for _ in range(app_module.LOGIN_MAX_FAILURES):
        post(client, '/login', {'username': 'user01', 'password': 'wrong'})
    queries_before = len(fake_db.executed)
    # even the CORRECT password is refused now, and the database is not asked at all
    fake_db.on('FROM [User] WHERE Username = ?', [('User01', generate_password_hash('secret1'), 'Customer', 'Ali')])
    post(client, '/login', {'username': 'user01', 'password': 'secret1'})
    assert 'Too many failed login attempts' in flashes(client)[-1]
    assert len(fake_db.executed) == queries_before


def test_successful_login_resets_the_failure_counter(client, fake_db, app_module):
    guest_token(client)
    user = [('User01', generate_password_hash('secret1'), 'Customer', 'Ali')]
    for _ in range(app_module.LOGIN_MAX_FAILURES - 1):
        post(client, '/login', {'username': 'user01', 'password': 'wrong'})
    fake_db.on('FROM [User] WHERE Username = ?', user)
    post(client, '/login', {'username': 'user01', 'password': 'secret1'})
    assert app_module._failed_logins == {}


# ===================================================================== booking

def _booking_form(**changes):
    data = {'cinema_id': '2', 'hall_number': '1', 'show_date': '2030-01-02', 'start_time': '18:00:00',
            'row_no': '3', 'seat_no': '4'}
    data.update(changes)
    return data


def _book_ready_db(fake_db, seat_exists=1, seat_taken=0, open_reservations=0):
    fake_db.on('FROM [Session] S JOIN Cinema C', [('Farhang', 'Inception', Decimal('150000'))])
    fake_db.on('SELECT COUNT(*) FROM Seat WHERE', [(seat_exists,)])
    fake_db.on('SELECT COUNT(*) FROM Ticket WHERE CinemaID', [(seat_taken,)])
    fake_db.on("T.TicketStatus IN ('Reserved', 'Pending')", [(open_reservations,)])


def test_booking_redirects_to_the_ticket_page(client, fake_db):
    login_as(client, username='User01')
    _book_ready_db(fake_db)
    resp = post(client, '/book', _booking_form(username='someone_else', status='Paid', price='1'))
    assert resp.status_code == 302
    location = resp.headers['Location']
    assert '/ticket/' in location                                    # Post/Redirect/Get
    insert_sql, params = fake_db.sql_containing('INSERT INTO Ticket')[0]
    assert "'Reserved'" in insert_sql
    assert params[1] == 'User01'                                     # from the session, not the form
    assert location.endswith(params[0])                              # redirected to the new ticket
    assert params[2:] == (2, 1, '2030-01-02', '18:00:00', 3, 4)
    assert fake_db.commits >= 1


def test_booking_only_accepts_future_showtimes(client, fake_db):
    login_as(client)
    _book_ready_db(fake_db)
    post(client, '/book', _booking_form())
    select = fake_db.sql_containing('FROM [Session] S JOIN Cinema C')[0][0]
    assert 'GETDATE()' in select


def test_booking_rejects_a_showtime_that_started_or_does_not_exist(client, fake_db):
    login_as(client)
    post(client, '/book', _booking_form())               # the session lookup returns nothing
    assert 'does not exist or has already started' in flashes(client)[-1]
    assert not fake_db.sql_containing('INSERT INTO Ticket')


@pytest.mark.parametrize('kwargs, message', [
    ({'seat_exists': 0}, 'does not exist in the selected hall'),
    ({'seat_taken': 1}, 'already taken'),
    ({'open_reservations': 6}, 'unpaid reservations'),
])
def test_booking_refusals(client, fake_db, kwargs, message):
    login_as(client)
    _book_ready_db(fake_db, **kwargs)
    post(client, '/book', _booking_form())
    assert message in flashes(client)[-1]
    assert not fake_db.sql_containing('INSERT INTO Ticket')


@pytest.mark.parametrize('changes', [{'show_date': '2030-13-45'}, {'show_date': 'tomorrow'},
                                     {'start_time': '25:99'}, {'row_no': ''}, {'seat_no': 'abc'}])
def test_booking_validates_input_before_touching_the_database(client, fake_db, changes):
    login_as(client)
    post(client, '/book', _booking_form(**changes))
    assert not fake_db.executed
    assert flashes(client)


def test_booking_race_is_reported_nicely(client, fake_db):
    login_as(client)
    _book_ready_db(fake_db)
    fake_db.on('INSERT INTO Ticket', pyodbc.IntegrityError('UX_Ticket_ActiveSeat'))
    resp = post(client, '/book', _booking_form())
    assert 'already booked' in flashes(client)[-1] and resp.headers['Location'].endswith('/')
    assert fake_db.rollbacks == 1 and fake_db.closed


def test_booking_requires_login(client, fake_db):
    guest_token(client)
    resp = post(client, '/book', _booking_form())
    assert '/login_page' in resp.headers['Location'] and not fake_db.executed


def test_showtimes_api(client, fake_db):
    fake_db.on('FROM [Session] S', [(2, 'Farhang', 1, date(2030, 1, 2), time(18, 0), Decimal('150000.00'))])
    data = client.get('/get_showtimes/7').get_json()
    assert data == [{'cinema_id': 2, 'cinema_name': 'Farhang', 'hall_number': 1, 'show_date': '2030-01-02',
                     'start_time': '18:00:00', 'price': 150000.0}]
    sql, params = fake_db.executed[0]
    assert params == (7,) and 'GETDATE()' in sql and 'ShowDate >= CAST' not in sql   # time-aware, not date-only


# ===================================================================== pages (templates render with the right data)

def _ticket(status='Reserved', **changes):
    data = dict(TicketID=TICKET_ID, Username='user01', RowNo=3, SeatNo=4, TicketStatus=status,
                BuyDate=datetime(2030, 1, 1, 12, 0), Title='Inception', CinemaName='Farhang',
                HallNumber=1, ShowDate=date(2030, 1, 2), StartTime=time(18, 0), Price=Decimal('150000.00'),
                PaymentRef=None, PaymentStatus=None, IsFuture=1)
    data.update(changes)
    return row(**data)


def _page(client, fake_db, ticket, url=None, **login):
    login_as(client, **login)
    fake_db.on('WHERE T.QRCode = ?', [ticket] if ticket else [])
    return client.get(url or f'/ticket/{TICKET_ID}')


def test_reserved_ticket_page_offers_pay_cancel_and_print(client, fake_db):
    html = _page(client, fake_db, _ticket('Reserved')).get_data(as_text=True)
    assert 'Seat reserved' in html and 'Pay online (simulation)' in html
    assert 'Cancel reservation' in html and 'Print Ticket' in html
    assert f'/pay/{TICKET_ID}' in html and 'Simulation only' in html
    assert '150,000 Toman' in html and '18:00' in html
    assert f'value="{TOKEN}"' in html


def test_paid_ticket_page_has_no_pay_or_cancel_button(client, fake_db):
    html = _page(client, fake_db, _ticket('Paid', PaymentRef='SIM-ABC', PaymentStatus='Paid')).get_data(as_text=True)
    assert 'Ticket paid' in html and 'Pay online' not in html and 'Cancel reservation' not in html
    assert '/payment/SIM-ABC' in html


def test_pending_and_failed_ticket_pages(client, fake_db):
    html = _page(client, fake_db, _ticket('Pending', PaymentRef='SIM-P')).get_data(as_text=True)
    assert 'Payment in progress' in html and 'Pay online' not in html
    html = _page(client, fake_db, _ticket('Failed')).get_data(as_text=True)
    assert 'Booking not active' in html and 'not valid for entry' in html
    assert 'Print Ticket' not in html and 'Pay online' not in html


def test_no_pay_button_when_show_started_or_simulation_off(client, fake_db, monkeypatch):
    html = _page(client, fake_db, _ticket('Reserved', IsFuture=0)).get_data(as_text=True)
    assert 'Pay online' not in html and f'/pay/{TICKET_ID}' not in html and 'Cancel reservation' in html
    assert 'Pay at the cinema counter' in html
    monkeypatch.setenv('PAYMENT_SIMULATION', '0')
    html = _page(client, fake_db, _ticket('Reserved')).get_data(as_text=True)
    assert 'Pay online' not in html and f'/pay/{TICKET_ID}' not in html


def test_ticket_of_another_user_is_404_for_customers_but_visible_to_staff(client, fake_db):
    resp = _page(client, fake_db, None)                       # SQL filters by owner -> no row
    assert resp.status_code == 404
    assert fake_db.sql_containing('WHERE T.QRCode = ?')[0][1] == (TICKET_ID, 'user01')   # owner filter was applied
    fake_db.executed.clear()
    html = _page(client, fake_db, _ticket('Paid', Username='someone'), username='cashier01', role='Staff')
    assert fake_db.sql_containing('WHERE T.QRCode = ?')[-1][1] == (TICKET_ID,)           # staff: no owner filter
    assert 'someone' in html.get_data(as_text=True)
    assert 'Pay online' not in html.get_data(as_text=True)    # staff cannot pay someone else's ticket


def test_ticket_page_embeds_safe_json_for_printing(client, fake_db):
    html = _page(client, fake_db, _ticket(Title='</script><b>x')).get_data(as_text=True)
    assert '</script><b>x' not in html                        # escaped by tojson
    assert 'const TICKET =' in html


def test_cancel_reservation(client, fake_db):
    login_as(client)
    post(client, f'/ticket/{TICKET_ID}/cancel')
    sql, params = fake_db.sql_containing("SET TicketStatus = 'Failed'")[0]
    assert params == (TICKET_ID, 'user01') and "TicketStatus = 'Reserved'" in sql and 'PaymentID IS NULL' in sql
    assert 'cancelled' in flashes(client)[-1]


def test_cancel_refused_when_nothing_matches(client, fake_db):
    login_as(client)
    fake_db.on("SET TicketStatus = 'Failed'", rowcount=0)
    post(client, f'/ticket/{TICKET_ID}/cancel')
    assert 'cannot be cancelled' in flashes(client)[-1]


def test_my_tickets_page(client, fake_db):
    login_as(client)
    fake_db.on('WHERE T.Username = ?', [row(
        TicketID=TICKET_ID, RowNo=3, SeatNo=4, TicketStatus='Paid', BuyDate=datetime(2030, 1, 1),
        Title='Inception', CinemaName='Farhang', HallNumber=1, ShowDate=date(2030, 1, 2), StartTime=time(18, 0))])
    html = client.get('/my_tickets').get_data(as_text=True)
    assert 'Inception' in html and 'status-paid' in html and f'/ticket/{TICKET_ID}' in html
    assert fake_db.sql_containing('WHERE T.Username = ?')[0][1] == ('user01',)


def test_my_tickets_empty_state(client, fake_db):
    login_as(client)
    assert 'No tickets yet' in client.get('/my_tickets').get_data(as_text=True)


def _payment(status, **changes):
    data = dict(Reference='SIM-ABC', PaymentStatus=status, Amount=Decimal('150000.00'),
                PaymentDate=datetime(2030, 1, 1, 12, 0, 0),
                CompletedDate=None if status == 'Pending' else datetime(2030, 1, 1, 12, 0, 1),
                FailureReason='SIMULATED_DECLINE' if status == 'Failed' else None,
                Method='SimulatedGateway' if status == 'Paid' else None, TicketID=TICKET_ID,
                TicketStatus=status, RowNo=3, SeatNo=4, HallNumber=1, ShowDate=date(2030, 1, 2),
                StartTime=time(18, 0), Title='Inception', CinemaName='Farhang')
    data.update(changes)
    return row(**data)


def _payment_page(client, fake_db, payment, **login):
    login_as(client, **login)
    fake_db.on('FROM Payment P JOIN Ticket T', [payment] if payment else [])
    return client.get('/payment/SIM-ABC')


def test_payment_result_paid(client, fake_db):
    html = _payment_page(client, fake_db, _payment('Paid')).get_data(as_text=True)
    assert 'Payment successful' in html and 'Simulation.' in html and 'not a decision of any bank' in html
    assert '150,000 Toman' in html and 'SimulatedGateway' in html


def test_payment_result_failed_explains_why(client, fake_db):
    html = _payment_page(client, fake_db, _payment('Failed')).get_data(as_text=True)
    assert 'Payment failed' in html and 'declined this payment' in html
    assert 'seat has been released' in html and 'Simulation.' in html


def test_payment_result_pending_refreshes_itself(client, fake_db):
    html = _payment_page(client, fake_db, _payment('Pending')).get_data(as_text=True)
    assert 'being processed' in html and 'http-equiv="refresh"' in html
    assert 'http-equiv="refresh"' not in _payment_page(client, fake_db, _payment('Paid')).get_data(as_text=True)


def test_cash_payment_is_not_labelled_as_simulation(client, fake_db):
    html = _payment_page(client, fake_db, _payment('Paid', Reference='CASH-1', Method='Cash')).get_data(as_text=True)
    assert 'Simulation.' not in html


def test_payment_of_another_user_is_404(client, fake_db):
    assert _payment_page(client, fake_db, None).status_code == 404
    assert fake_db.sql_containing('FROM Payment P JOIN Ticket T')[0][1] == ('SIM-ABC', 'user01')


# ===================================================================== /pay

def _pay_ready_db(fake_db):
    fake_db.on("SELECT S.Price FROM Ticket T", [(Decimal('150000.00'),)])
    fake_db.on("INSERT INTO Payment", [(5,)])


def _final_ticket_update(fake_db):
    return fake_db.sql_containing('UPDATE Ticket SET TicketStatus = ? WHERE')[0][1]


def test_pay_success(client, fake_db, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '0')
    login_as(client)
    _pay_ready_db(fake_db)
    resp = post(client, f'/pay/{TICKET_ID}')
    assert resp.status_code == 302 and '/payment/SIM-' in resp.headers['Location']     # PRG
    assert _final_ticket_update(fake_db) == ('Paid', TICKET_ID, 5)
    assert fake_db.sql_containing('INSERT INTO PaymentMethod')


def test_pay_simulated_failure_releases_the_seat_and_never_marks_paid(client, fake_db, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '1')
    login_as(client)
    _pay_ready_db(fake_db)
    resp = post(client, f'/pay/{TICKET_ID}')
    assert '/payment/SIM-' in resp.headers['Location']                                  # failure is a normal result
    assert _final_ticket_update(fake_db) == ('Failed', TICKET_ID, 5)
    reason = fake_db.sql_containing('UPDATE Payment SET PaymentStatus = ?')[0][1]
    assert reason[0] == 'Failed' and reason[1].startswith('SIMULATED_')
    assert not fake_db.sql_containing('INSERT INTO PaymentMethod')


def test_pay_ignores_everything_the_browser_claims(client, fake_db, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '1')
    login_as(client)
    _pay_ready_db(fake_db)
    post(client, f'/pay/{TICKET_ID}', {'status': 'Paid', 'success': 'true', 'amount': '1', 'outcome': 'Paid',
                                       'card_number': '4111111111111111', 'cvv': '123'})
    assert fake_db.sql_containing('INSERT INTO Payment')[0][1][0] == Decimal('150000.00')
    assert _final_ticket_update(fake_db)[0] == 'Failed'                                 # the server decided
    everything = ' '.join(str(p) for _, params in fake_db.executed for p in params)
    assert '4111' not in everything and '123' not in everything.replace('150000', '').replace(TICKET_ID, '')


def test_pay_second_request_loses_and_creates_no_second_payment(client, fake_db):
    login_as(client)
    _pay_ready_db(fake_db)
    fake_db.on("SET TicketStatus = 'Pending'", rowcount=0)                              # already claimed
    resp = post(client, f'/pay/{TICKET_ID}')
    assert resp.headers['Location'].endswith(f'/ticket/{TICKET_ID}')
    assert 'cannot be paid now' in flashes(client)[-1]
    assert not fake_db.sql_containing('UPDATE Payment SET PaymentStatus = ?')
    assert fake_db.rollbacks >= 1


def test_pay_unexpected_error_after_claim_leaves_ticket_pending_for_the_sweeper(client, fake_db, monkeypatch):
    monkeypatch.setenv('PAYMENT_FAILURE_RATE', '0')
    login_as(client)
    _pay_ready_db(fake_db)
    fake_db.on('UPDATE Payment SET PaymentStatus = ?', pyodbc.OperationalError('connection lost'))
    resp = post(client, f'/pay/{TICKET_ID}')
    assert resp.headers['Location'].endswith(f'/ticket/{TICKET_ID}')
    assert 'Something went wrong' in flashes(client)[-1]
    assert fake_db.rollbacks >= 1 and fake_db.closed
    assert not fake_db.sql_containing('INSERT INTO PaymentMethod')                      # nothing says Paid


def test_pay_when_simulation_is_off(client, fake_db, monkeypatch):
    monkeypatch.setenv('PAYMENT_SIMULATION', '0')
    login_as(client)
    post(client, f'/pay/{TICKET_ID}')
    assert 'switched off' in flashes(client)[-1] and not fake_db.executed


def test_pay_requires_login(client, fake_db):
    guest_token(client)
    resp = post(client, f'/pay/{TICKET_ID}')
    assert '/login_page' in resp.headers['Location'] and not fake_db.executed


def test_stale_pending_payments_are_swept_at_most_once_a_minute(client, fake_db):
    login_as(client)
    client.get('/my_tickets')
    client.get('/my_tickets')
    assert len(fake_db.sql_containing('PENDING_EXPIRED')) == 1


# ===================================================================== staff: dashboard, cash, CSV

def _dashboard_row(status, **changes):
    data = dict(TicketID=TICKET_ID, Username='user01', FirstName='Ali', LastName='Ahmadi', RowNo=3,
                SeatNo=4, TicketStatus=status, BuyDate=datetime(2030, 1, 1, 12, 0), Title='Inception',
                CinemaName='Farhang', ShowDate=date(2030, 1, 2), StartTime=time(18, 0), PaymentRef=None)
    data.update(changes)
    return row(**data)


def _dashboard_db(fake_db, tickets, total=None):
    fake_db.on('AS total_tickets', [row(total_tickets=total if total is not None else len(tickets),
                                        paid_tickets=1, reserved_tickets=2, pending_tickets=3)])
    fake_db.on('OFFSET ? ROWS', tickets)


def test_dashboard_shows_all_four_statuses_and_mark_paid_only_for_reserved(client, fake_db):
    login_as(client, username='cashier01', role='Staff')
    _dashboard_db(fake_db, [_dashboard_row('Reserved'), _dashboard_row('Paid', TicketID='aaaa-1', PaymentRef='SIM-Z'),
                            _dashboard_row('Pending', TicketID='bbbb-2'), _dashboard_row('Failed', TicketID='cccc-3')])
    html = client.get('/dashboard').get_data(as_text=True)
    assert 'Payment in Progress' in html and 'Total Tickets' in html
    assert html.count('Mark paid') == 1                                   # only the Reserved row
    for cls in ('status-paid', 'status-reserved', 'status-pending', 'status-failed'):
        assert cls in html
    assert 'Ali Ahmadi' in html and '/payment/SIM-Z' in html and '18:00' in html


def test_dashboard_pagination(client, fake_db, app_module):
    login_as(client, role='Admin')
    _dashboard_db(fake_db, [_dashboard_row('Paid')], total=app_module.DASHBOARD_PAGE_SIZE * 2 + 1)
    html = client.get('/dashboard?page=2').get_data(as_text=True)
    assert 'Page 2 of 3' in html and 'Previous' in html and 'Next' in html
    assert fake_db.sql_containing('OFFSET ? ROWS')[0][1] == (app_module.DASHBOARD_PAGE_SIZE, app_module.DASHBOARD_PAGE_SIZE)
    fake_db.executed.clear()
    client.get('/dashboard?page=999')                                       # clamped to the last page
    assert fake_db.sql_containing('OFFSET ? ROWS')[0][1][0] == app_module.DASHBOARD_PAGE_SIZE * 2


def test_dashboard_empty_state(client, fake_db):
    login_as(client, role='Staff')
    _dashboard_db(fake_db, [], total=0)
    assert 'No Bookings Found' in client.get('/dashboard').get_data(as_text=True)


def test_admin_sees_the_dashboard_link_in_the_menu(client, fake_db):
    login_as(client, username='admin01', role='Admin')
    fake_db.on('SELECT DISTINCT Genre', [])
    html = client.get('/').get_data(as_text=True)
    assert '/dashboard' in html and 'My Tickets' in html
    login_as(client, username='user01', role='Customer')
    assert '/dashboard' not in client.get('/').get_data(as_text=True)


def test_staff_mark_paid_cash(client, fake_db):
    login_as(client, username='cashier01', role='Staff')
    fake_db.on("SELECT S.Price FROM Ticket T", [(Decimal('150000'),)])
    fake_db.on("INSERT INTO Payment", [(8,)])
    resp = post(client, f'/staff/ticket/{TICKET_ID}/mark_paid', {'page': '2'})
    assert resp.status_code == 302 and 'page=2' in resp.headers['Location']
    assert 'CASH-' in flashes(client)[-1]
    assert fake_db.sql_containing("SET TicketStatus = 'Paid', PaymentID = ?")


def test_staff_mark_paid_refused_when_not_reserved(client, fake_db):
    login_as(client, role='Staff')
    post(client, f'/staff/ticket/{TICKET_ID}/mark_paid')
    assert 'nothing was changed' in flashes(client)[-1]


def test_customer_cannot_mark_paid(client, fake_db):
    login_as(client)
    resp = post(client, f'/staff/ticket/{TICKET_ID}/mark_paid')
    assert resp.status_code == 302 and not fake_db.executed


def test_csv_export_has_full_ticket_ids_bom_and_formula_protection(client, fake_db):
    login_as(client, role='Staff')
    fake_db.on('FROM Ticket T JOIN [User] U', [_dashboard_row('Paid', FirstName='=HYPERLINK("http://evil")',
                                                               PaymentRef='SIM-Z', PaymentStatus='Paid',
                                                               HallNumber=1)])
    resp = client.get('/dashboard/export.csv')
    body = resp.get_data(as_text=True)
    assert resp.mimetype == 'text/csv' and body.startswith('\ufeff"Ticket ID"')
    assert TICKET_ID in body and TICKET_ID[:20] + '...' not in body            # the FULL number
    assert "\"'=HYPERLINK" in body                                              # spreadsheet formulas are neutralised
    assert 'attachment; filename=cinema_bookings_' in resp.headers['Content-Disposition']
    assert 'OFFSET' not in fake_db.executed[0][0]                               # all bookings, not one page


# ===================================================================== index page and showtime picker

def test_index_guest_and_customer(client, fake_db):
    fake_db.on('SELECT DISTINCT Genre', [('Drama',), ('Sci-Fi',)])
    fake_db.on('LEFT JOIN MovieGenre G', [row(FilmID=1, Title='Inception', AgeRating='PG-13', DurationMin=148,
                                              Director='Nolan', Genre='Sci-Fi, Thriller')])
    html = client.get('/?search=inc&genre=Sci-Fi').get_data(as_text=True)
    assert 'Inception' in html and 'Login to Book' in html and 'id="bookingModal"' not in html
    assert 'Thriller' in html and 'selected' in html
    sql, params = fake_db.sql_containing('LEFT JOIN MovieGenre G')[0]
    assert params == ['%inc%', 'Sci-Fi'] or params == ('%inc%', 'Sci-Fi')
    login_as(client)
    html = client.get('/').get_data(as_text=True)
    assert 'id="bookingModal"' in html and 'Book Ticket' in html and f'value="{TOKEN}"' in html


def test_index_script_does_not_crash_for_guests_and_shows_toman(client, fake_db):
    guest = client.get('/').get_data(as_text=True)
    assert "const bookingForm = document.getElementById('bookingForm');" in guest
    assert 'if (bookingForm)' in guest
    assert "' Toman)'" in guest and "($' +" not in guest


def test_register_page_has_no_fake_role_selector_and_has_length_limits(client):
    html = client.get('/register_page').get_data(as_text=True)
    assert 'name="role"' not in html and 'maxlength="50"' in html and 'maxlength="80"' in html


def test_secret_key_is_not_the_old_hard_coded_value(app_module):
    assert app_module.app.secret_key != 'university_project_key_change_in_production'
    assert len(app_module.app.secret_key) >= 32
