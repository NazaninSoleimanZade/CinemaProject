"""Run clear_bookings — delete all tickets/payments. Delete this file after use."""
from database import get_db_connection

conn = get_db_connection()
if not conn:
    print('CANNOT CONNECT'); exit(1)

conn.autocommit = False
c = conn.cursor()

try:
    print('Deleting PaymentMethod rows...')
    c.execute('DELETE FROM dbo.PaymentMethod')
    print(f'  {c.rowcount} rows deleted.')

    print('Deleting Ticket rows...')
    c.execute('DELETE FROM dbo.Ticket')
    print(f'  {c.rowcount} rows deleted.')

    print('Deleting Payment rows...')
    c.execute('DELETE FROM dbo.Payment')
    print(f'  {c.rowcount} rows deleted.')

    # Verify
    results = {}
    for tbl in ('Ticket', 'Payment', 'PaymentMethod'):
        c.execute(f'SELECT COUNT(*) FROM dbo.[{tbl}]')
        results[tbl] = c.fetchone()[0]
    print('\nPost-delete counts:', results)

    if all(v == 0 for v in results.values()):
        conn.commit()
        print('COMMITTED.')
    else:
        conn.rollback()
        print('UNEXPECTED ROWS REMAIN — ROLLED BACK.')

    # Reset Payment identity counter
    c.execute("DBCC CHECKIDENT ('dbo.Payment', RESEED, 0)")
    conn.commit()
    print('Payment identity counter reset to 0.')

except Exception as e:
    conn.rollback()
    print(f'ERROR — ROLLED BACK: {e}')
    raise
finally:
    conn.close()
