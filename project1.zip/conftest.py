"""Shared test helpers.

The unit tests do NOT need SQL Server: `fake_db` replaces the database connection with
an object that records every SQL statement and answers with rows prepared by the test.
(It checks the application's logic, the templates and the SQL parameters. It cannot
check that the SQL itself is valid T-SQL: that is what test_payments_db.py is for.)
"""
import os
import sys
from collections import namedtuple

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def row(**fields):
    """A fake database row: supports row.Column and row[0] like a pyodbc Row."""
    return namedtuple('Row', list(fields))(**fields)


class FakeCursor:
    def __init__(self, conn):
        self.conn = conn
        self._rows = []
        self.rowcount = 1

    def execute(self, sql, params=()):
        text = ' '.join(sql.split())            # one line, single spaces
        self.conn.executed.append((text, tuple(params)))
        for needle, result, rowcount in self.conn.responses:
            if needle in text:
                if isinstance(result, Exception):
                    raise result
                self._rows = list(result)
                self.rowcount = rowcount
                return self
        self._rows, self.rowcount = [], 1
        return self

    def fetchone(self):
        return self._rows.pop(0) if self._rows else None

    def fetchall(self):
        rows, self._rows = self._rows, []
        return rows


class FakeConn:
    def __init__(self):
        self.responses = []      # (needle, rows | Exception, rowcount)
        self.executed = []       # (normalised sql, params)
        self.commits = self.rollbacks = 0
        self.closed = False

    def on(self, needle, rows=(), rowcount=1):
        """When a statement contains `needle`, answer with `rows` (or raise it if it is
        an Exception) and report `rowcount` affected rows. Registering the same needle
        again replaces the earlier answer."""
        self.responses[:] = [r for r in self.responses if r[0] != needle]
        self.responses.append((needle, rows, rowcount))
        return self

    def cursor(self):
        return FakeCursor(self)

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True

    def sql_containing(self, needle):
        return [(s, p) for s, p in self.executed if needle in s]


@pytest.fixture
def fake_db(monkeypatch):
    import database
    conn = FakeConn()
    monkeypatch.setattr(database, 'get_db_connection', lambda: conn)
    return conn


@pytest.fixture
def app_module():
    import app as app_module
    app_module.app.config['TESTING'] = True
    app_module._failed_logins.clear()
    app_module._last_sweep = None
    return app_module


@pytest.fixture
def client(app_module):
    return app_module.app.test_client()


TOKEN = 'test-csrf-token'


def login_as(client, username='user01', role='Customer', first_name='Ali'):
    """Pretend that this browser is logged in (and has a CSRF token)."""
    with client.session_transaction() as s:
        s['username'], s['role'], s['first_name'] = username, role, first_name
        s['_csrf_token'] = TOKEN


def guest_token(client):
    with client.session_transaction() as s:
        s['_csrf_token'] = TOKEN


def post(client, url, data=None, **kwargs):
    """POST with a valid CSRF token."""
    data = dict(data or {})
    data['csrf_token'] = TOKEN
    return client.post(url, data=data, **kwargs)


def flashes(client):
    """The flash messages waiting in the session (does not remove them)."""
    with client.session_transaction() as s:
        return [message for _category, message in s.get('_flashes', [])]
