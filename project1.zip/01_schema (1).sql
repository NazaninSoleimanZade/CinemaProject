USE [cinema];
GO

-- Filtered indexes require QUOTED_IDENTIFIER ON
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

-- This script only CREATES missing objects. It never drops anything,
-- so it is safe to run again on a database that already has data.

-------------------------------------------------------------------------
-- Cinema
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Cinema', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Cinema (
        CinemaID   INT IDENTITY(1,1) PRIMARY KEY,
        CinemaName NVARCHAR(100) NOT NULL,
        Phone1     NVARCHAR(20)  NOT NULL UNIQUE,
        Phone2     NVARCHAR(20)  NULL,
        Province   NVARCHAR(50)  NOT NULL,
        City       NVARCHAR(50)  NOT NULL,
        Street     NVARCHAR(80)  NULL,
        Alley      NVARCHAR(80)  NULL,
        CONSTRAINT CK_Cinema_Phone1 CHECK (Phone1 LIKE '[0-9+]%')
    );
END
GO

-------------------------------------------------------------------------
-- Hall
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Hall', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Hall (
        CinemaID   INT NOT NULL,
        HallNumber INT NOT NULL,
        Capacity   INT NOT NULL,

        CONSTRAINT PK_Hall PRIMARY KEY (CinemaID, HallNumber),
        CONSTRAINT CK_Hall_Capacity CHECK (Capacity > 0),
        CONSTRAINT FK_Hall_Cinema
            FOREIGN KEY (CinemaID) REFERENCES dbo.Cinema(CinemaID)
            ON DELETE CASCADE ON UPDATE CASCADE
    );
END
GO

-------------------------------------------------------------------------
-- Seat
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Seat', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Seat (
        CinemaID   INT NOT NULL,
        HallNumber INT NOT NULL,
        RowNo      INT NOT NULL,
        SeatNo     INT NOT NULL,
        SeatType   NVARCHAR(30) NULL,

        CONSTRAINT PK_Seat PRIMARY KEY (CinemaID, HallNumber, RowNo, SeatNo),
        CONSTRAINT FK_Seat_Hall
            FOREIGN KEY (CinemaID, HallNumber) REFERENCES dbo.Hall (CinemaID, HallNumber)
            ON DELETE CASCADE ON UPDATE CASCADE
    );
END
GO

-------------------------------------------------------------------------
-- Movie
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Movie', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Movie (
        FilmID       INT IDENTITY(1,1) PRIMARY KEY,
        ImdbID       NVARCHAR(20)  NOT NULL UNIQUE,
        Title        NVARCHAR(150) NOT NULL,
        AgeRating    NVARCHAR(20)  NULL,
        ReleaseYear  SMALLINT NOT NULL,
        ReleaseMonth TINYINT  NOT NULL,
        ReleaseDay   TINYINT  NOT NULL,
        DurationMin  INT NOT NULL,
        Director     NVARCHAR(100) NULL,
        Producer     NVARCHAR(100) NULL,
        Description  NVARCHAR(MAX) NULL,

        CONSTRAINT CK_Movie_ReleaseDate CHECK (
            ReleaseYear >= 1888 AND
            ReleaseMonth BETWEEN 1 AND 12 AND
            ReleaseDay   BETWEEN 1 AND 31
        ),
        CONSTRAINT CK_Movie_Duration CHECK (DurationMin > 0)
    );
END
GO

-------------------------------------------------------------------------
-- Session (a showtime)
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.[Session]', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[Session] (
        CinemaID   INT NOT NULL,
        HallNumber INT NOT NULL,
        ShowDate   DATE NOT NULL,
        StartTime  TIME(0) NOT NULL,
        EndTime    TIME(0) NOT NULL,
        FilmID     INT NOT NULL,
        Price      DECIMAL(10,2) NOT NULL,

        CONSTRAINT PK_Session PRIMARY KEY (CinemaID, HallNumber, ShowDate, StartTime),
        CONSTRAINT FK_Session_Hall
            FOREIGN KEY (CinemaID, HallNumber) REFERENCES dbo.Hall (CinemaID, HallNumber)
            ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT FK_Session_Movie
            FOREIGN KEY (FilmID) REFERENCES dbo.Movie(FilmID)
            ON DELETE NO ACTION ON UPDATE CASCADE,
        CONSTRAINT CK_Session_Time  CHECK (EndTime > StartTime),
        CONSTRAINT CK_Session_Price CHECK (Price > 0)
    );
END
GO

-------------------------------------------------------------------------
-- User
-- Email is NOT declared UNIQUE here: SQL Server's UNIQUE allows only ONE
-- NULL, so a second user without email would fail. A filtered unique index
-- (below) enforces uniqueness only for non-NULL emails.
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.[User]', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[User] (
        Username   NVARCHAR(50)  NOT NULL PRIMARY KEY,
        [Password] NVARCHAR(255) NOT NULL,
        Role       NVARCHAR(30)  NOT NULL,
        Email      NVARCHAR(120) NULL,
        FirstName  NVARCHAR(50)  NOT NULL,
        LastName   NVARCHAR(80)  NOT NULL,
        Phone      NVARCHAR(20)  NULL,

        CONSTRAINT CK_User_Role CHECK (Role IN (N'Customer', N'Staff', N'Admin', N'Operator'))
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'UX_User_Email' AND object_id = OBJECT_ID(N'dbo.[User]'))
    CREATE UNIQUE INDEX UX_User_Email ON dbo.[User](Email) WHERE Email IS NOT NULL;
GO

-------------------------------------------------------------------------
-- Payment
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Payment', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Payment (
        PaymentID     BIGINT IDENTITY(1,1) PRIMARY KEY,
        PaymentDate   DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        Amount        DECIMAL(10,2) NOT NULL,
        PaymentStatus NVARCHAR(30)  NOT NULL,

        CONSTRAINT CK_Payment_Amount CHECK (Amount > 0),
        CONSTRAINT CK_Payment_Status CHECK (PaymentStatus IN (N'Pending', N'Paid', N'Failed'))
    );
END
GO

-------------------------------------------------------------------------
-- Ticket
-- No UNIQUE constraint on the seat here. The rule "one active ticket per
-- seat per session" is a filtered unique index below, so that a Failed
-- ticket does NOT block the seat from being booked again.
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Ticket', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Ticket (
        QRCode       NVARCHAR(80) NOT NULL PRIMARY KEY,
        Username     NVARCHAR(50) NOT NULL,

        CinemaID     INT NOT NULL,
        HallNumber   INT NOT NULL,
        ShowDate     DATE NOT NULL,
        StartTime    TIME(0) NOT NULL,

        RowNo        INT NOT NULL,
        SeatNo       INT NOT NULL,

        PaymentID    BIGINT NULL,
        TicketStatus NVARCHAR(30) NOT NULL,
        BuyDate      DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

        CONSTRAINT CK_Ticket_Status
            CHECK (TicketStatus IN (N'Reserved', N'Paid', N'Pending', N'Failed')),

        CONSTRAINT FK_Ticket_User
            FOREIGN KEY (Username) REFERENCES dbo.[User](Username),

        CONSTRAINT FK_Ticket_Session
            FOREIGN KEY (CinemaID, HallNumber, ShowDate, StartTime)
            REFERENCES dbo.[Session](CinemaID, HallNumber, ShowDate, StartTime)
            ON DELETE CASCADE ON UPDATE CASCADE,

        CONSTRAINT FK_Ticket_Seat
            FOREIGN KEY (CinemaID, HallNumber, RowNo, SeatNo)
            REFERENCES dbo.Seat (CinemaID, HallNumber, RowNo, SeatNo)
            ON DELETE NO ACTION ON UPDATE NO ACTION,

        CONSTRAINT FK_Ticket_Payment
            FOREIGN KEY (PaymentID) REFERENCES dbo.Payment(PaymentID)
            ON DELETE SET NULL ON UPDATE CASCADE
    );
END
GO

-- Double-booking protection: Reserved / Paid / Pending tickets hold the seat,
-- Failed tickets do not.
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'UX_Ticket_ActiveSeat' AND object_id = OBJECT_ID(N'dbo.Ticket'))
    CREATE UNIQUE INDEX UX_Ticket_ActiveSeat
        ON dbo.Ticket (CinemaID, HallNumber, ShowDate, StartTime, RowNo, SeatNo)
        WHERE TicketStatus <> N'Failed';
GO

-------------------------------------------------------------------------
-- Many-to-many helper tables
-------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.MovieGenre', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MovieGenre (
        FilmID INT NOT NULL,
        Genre  NVARCHAR(50) NOT NULL,
        CONSTRAINT PK_MovieGenre PRIMARY KEY (FilmID, Genre),
        CONSTRAINT FK_MovieGenre_Movie
            FOREIGN KEY (FilmID) REFERENCES dbo.Movie(FilmID)
            ON DELETE CASCADE ON UPDATE NO ACTION
    );
END
GO

IF OBJECT_ID(N'dbo.MovieActor', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MovieActor (
        FilmID        INT NOT NULL,
        ActorLastName NVARCHAR(100) NOT NULL,
        CONSTRAINT PK_MovieActor PRIMARY KEY (FilmID, ActorLastName),
        CONSTRAINT FK_MovieActor_Movie
            FOREIGN KEY (FilmID) REFERENCES dbo.Movie(FilmID)
            ON DELETE CASCADE ON UPDATE NO ACTION
    );
END
GO

IF OBJECT_ID(N'dbo.MovieLanguage', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MovieLanguage (
        FilmID     INT NOT NULL,
        [Language] NVARCHAR(50) NOT NULL,
        CONSTRAINT PK_MovieLanguage PRIMARY KEY (FilmID, [Language]),
        CONSTRAINT FK_MovieLanguage_Movie
            FOREIGN KEY (FilmID) REFERENCES dbo.Movie(FilmID)
            ON DELETE CASCADE ON UPDATE NO ACTION
    );
END
GO

IF OBJECT_ID(N'dbo.PaymentMethod', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PaymentMethod (
        PaymentID  BIGINT NOT NULL,
        MethodType NVARCHAR(50) NOT NULL,
        CONSTRAINT PK_PaymentMethod PRIMARY KEY (PaymentID, MethodType),
        CONSTRAINT FK_PaymentMethod_Payment
            FOREIGN KEY (PaymentID) REFERENCES dbo.Payment(PaymentID)
            ON DELETE CASCADE ON UPDATE NO ACTION
    );
END
GO
