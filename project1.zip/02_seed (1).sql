USE [cinema];
GO

SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

-- Everything below is ONE batch (no GO) so the variables stay alive.

-- Safety guard: never seed on top of existing data.
IF EXISTS (SELECT 1 FROM dbo.Cinema) OR EXISTS (SELECT 1 FROM dbo.[User])
BEGIN
    PRINT N'Seed skipped: the database already contains data. Run 00_reset.sql first for a clean start.';
    RETURN;
END

DECLARE @Today DATE = CAST(GETDATE() AS DATE);
DECLARE @C1 INT, @C2 INT;                       -- CinemaIDs
DECLARE @F1 INT, @F2 INT, @F3 INT;              -- FilmIDs
DECLARE @P1 BIGINT, @P2 BIGINT, @P3 BIGINT, @P4 BIGINT;  -- PaymentIDs

-------------------------------------------------------------------------
-- Cinemas, halls
-------------------------------------------------------------------------
INSERT INTO dbo.Cinema (CinemaName, Phone1, Phone2, Province, City, Street, Alley)
VALUES (N'Mellat Cinema', N'02198765432', N'02198765433', N'Tehran', N'Tehran', N'Valiasr St', N'Park Alley');
SET @C1 = SCOPE_IDENTITY();

INSERT INTO dbo.Cinema (CinemaName, Phone1, Phone2, Province, City, Street, Alley)
VALUES (N'Cinema Farhang', N'02634567890', NULL, N'Alborz', N'Karaj', N'Shahid Beheshti St', N'Alley 3');
SET @C2 = SCOPE_IDENTITY();

INSERT INTO dbo.Hall (CinemaID, HallNumber, Capacity)
VALUES (@C1, 3, 200), (@C2, 1, 200), (@C1, 2, 200);

-------------------------------------------------------------------------
-- Movies (+ genres, actors, languages)
-------------------------------------------------------------------------
INSERT INTO dbo.Movie (ImdbID, Title, AgeRating, ReleaseYear, ReleaseMonth, ReleaseDay, DurationMin, Director, Producer, Description)
VALUES (N'tt0111161', N'The Shawshank Redemption', N'R', 1994, 9, 23, 142, N'Frank Darabont', N'Niki Marvin',
        N'Two imprisoned men bond over a number of years, finding solace and eventual redemption.');
SET @F1 = SCOPE_IDENTITY();

INSERT INTO dbo.Movie (ImdbID, Title, AgeRating, ReleaseYear, ReleaseMonth, ReleaseDay, DurationMin, Director, Producer, Description)
VALUES (N'tt1375666', N'Inception', N'PG-13', 2010, 7, 16, 148, N'Christopher Nolan', N'Emma Thomas',
        N'A thief who steals corporate secrets through dream-sharing technology.');
SET @F2 = SCOPE_IDENTITY();

INSERT INTO dbo.Movie (ImdbID, Title, AgeRating, ReleaseYear, ReleaseMonth, ReleaseDay, DurationMin, Director, Producer, Description)
VALUES (N'tt1832382', N'جدایی نادر از سیمین', N'+12', 2011, 2, 15, 123, N'اصغر فرهادی', N'اصغر فرهادی',
        N'درامی اجتماعی درباره یک زوج ایرانی درگیر مسائل خانوادگی.');
SET @F3 = SCOPE_IDENTITY();

INSERT INTO dbo.MovieGenre (FilmID, Genre) VALUES
(@F1, N'Drama'), (@F1, N'Crime'),
(@F2, N'Sci-Fi'), (@F2, N'Action'), (@F2, N'Thriller'),
(@F3, N'Drama'), (@F3, N'Family');

INSERT INTO dbo.MovieActor (FilmID, ActorLastName) VALUES
(@F1, N'Robbins'), (@F1, N'Freeman'),
(@F2, N'DiCaprio'), (@F2, N'Hardy'), (@F2, N'Page'),
(@F3, N'معادی'), (@F3, N'حاتمی'), (@F3, N'شهاب حسینی');

INSERT INTO dbo.MovieLanguage (FilmID, [Language]) VALUES
(@F1, N'English'),
(@F2, N'English'), (@F2, N'Japanese'), (@F2, N'French'),
(@F3, N'Persian');

-------------------------------------------------------------------------
-- Sessions: the same 3 daily slots for each of the next 30 days, so the
-- demo never runs out of future showtimes right after seeding.
-------------------------------------------------------------------------
;WITH Days AS (
    SELECT 1 AS d
    UNION ALL
    SELECT d + 1 FROM Days WHERE d < 30
)
INSERT INTO dbo.[Session] (CinemaID, HallNumber, ShowDate, StartTime, EndTime, FilmID, Price)
SELECT s.CinemaID, s.HallNumber, DATEADD(DAY, dy.d, @Today),
       CAST(s.StartTime AS TIME(0)), CAST(s.EndTime AS TIME(0)), s.FilmID, s.Price
FROM (VALUES
        (@C2, 1, '18:00', '20:30', @F1, 150000.00),
        (@C1, 3, '21:00', '23:30', @F2, 180000.00),
        (@C1, 2, '17:30', '19:40', @F3, 120000.00)
     ) AS s (CinemaID, HallNumber, StartTime, EndTime, FilmID, Price)
CROSS JOIN Days AS dy;

-------------------------------------------------------------------------
-- Seats: generated for EVERY hall in one statement.
-- 20 seats per row, rows 1-2 are VIP. Exactly Capacity seats per hall
-- (200 -> 10 rows x 20), which matches the max values on the booking form.
-------------------------------------------------------------------------
DECLARE @MaxCap INT = (SELECT MAX(Capacity) FROM dbo.Hall);

INSERT INTO dbo.Seat (CinemaID, HallNumber, RowNo, SeatNo, SeatType)
SELECT h.CinemaID, h.HallNumber,
       (nums.n - 1) / 20 + 1,
       (nums.n - 1) % 20 + 1,
       CASE WHEN (nums.n - 1) / 20 + 1 <= 2 THEN N'VIP' ELSE N'Normal' END
FROM dbo.Hall AS h
CROSS JOIN (
    SELECT TOP (@MaxCap) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
    FROM sys.all_objects AS a
    CROSS JOIN sys.all_objects AS b
) AS nums
WHERE nums.n <= h.Capacity;

-------------------------------------------------------------------------
-- Users.  Passwords are Werkzeug hashes (same as before).
-- To change one: python -c "from werkzeug.security import generate_password_hash as g; print(g('NewPass'))"
-- then UPDATE dbo.[User] SET [Password] = N'<hash>' WHERE Username = N'user01';
-------------------------------------------------------------------------
INSERT INTO dbo.[User] (Username, [Password], Role, Email, FirstName, LastName, Phone) VALUES
(N'admin01',    N'pbkdf2:sha256:600000$2d8974521f2d0cd3$bd037bb533a54b11109752dbbedb7954c47c70a3393e0f21043c706d86994893', N'Admin',    N'admin@cinema.com',     N'علی',   N'محمدی', N'09120000001'),
(N'cashier01',  N'pbkdf2:sha256:600000$1a0b75d0721f45dc$e22c02c3ebfabd9c659a2ff3a14d31f02415d3aab5aa5329743b692abddcfee1', N'Staff',    N'cashier01@cinema.com', N'سارا',  N'کاظمی', N'09120000002'),
(N'operator01', N'pbkdf2:sha256:600000$cb4287ef768954fc$8b661ebb8a8882bcf0e283b077966870b9464501577fe2b1b445d23577a3645a', N'Operator', N'operator01@cinema.com', N'مهدی',  N'رضایی', NULL),
(N'user01',     N'pbkdf2:sha256:600000$d6628efacf9bb7c4$62f2ce8dc8f479bd4b9753a328f22b64447ddd80d7c238b8138223218d96c97a', N'Customer', N'user01@gmail.com',      N'نازنین', N'احمدی', NULL);

-------------------------------------------------------------------------
-- Payments: one per ticket that has one, amount = ticket price (150000)
-------------------------------------------------------------------------
INSERT INTO dbo.Payment (Amount, PaymentStatus) VALUES (150000.00, N'Failed');   SET @P1 = SCOPE_IDENTITY();
INSERT INTO dbo.Payment (Amount, PaymentStatus) VALUES (150000.00, N'Pending');  SET @P2 = SCOPE_IDENTITY();
INSERT INTO dbo.Payment (Amount, PaymentStatus) VALUES (150000.00, N'Paid');     SET @P3 = SCOPE_IDENTITY();
INSERT INTO dbo.Payment (Amount, PaymentStatus) VALUES (150000.00, N'Paid');     SET @P4 = SCOPE_IDENTITY();

INSERT INTO dbo.PaymentMethod (PaymentID, MethodType) VALUES
(@P1, N'CreditCard'),
(@P2, N'OnlineGateway'),
(@P3, N'CreditCard'),
(@P3, N'Wallet'),
(@P4, N'Cash');

-------------------------------------------------------------------------
-- Tickets for tomorrow's 18:00 show (Cinema Farhang, hall 1)
-------------------------------------------------------------------------
DECLARE @TicketDate DATE = DATEADD(DAY, 1, @Today);

INSERT INTO dbo.Ticket (QRCode, Username, CinemaID, HallNumber, ShowDate, StartTime, RowNo, SeatNo, PaymentID, TicketStatus)
VALUES
(N'QR-SEED-R1S1',  N'user01',     @C2, 1, @TicketDate, '18:00:00', 1,  1, @P3,  N'Paid'),
(N'QR-SEED-R1S2',  N'user01',     @C2, 1, @TicketDate, '18:00:00', 1,  2, NULL, N'Reserved'),
(N'QR-SEED-R1S4',  N'operator01', @C2, 1, @TicketDate, '18:00:00', 1,  4, @P2,  N'Pending'),
(N'QR-SEED-R2S10', N'admin01',    @C2, 1, @TicketDate, '18:00:00', 2, 10, @P1,  N'Failed'),
(N'QR-SEED-R5S1',  N'cashier01',  @C2, 1, @TicketDate, '18:00:00', 5,  1, @P4,  N'Paid'),
(N'QR-SEED-R5S3',  N'user01',     @C2, 1, @TicketDate, '18:00:00', 5,  3, NULL, N'Reserved');

-------------------------------------------------------------------------
-- Final verification (expected: 2 cinemas, 3 halls, 600 seats,
-- 90 sessions, 4 users, 6 tickets)
-------------------------------------------------------------------------
SELECT (SELECT COUNT(*) FROM dbo.Cinema)   AS Cinemas,
       (SELECT COUNT(*) FROM dbo.Hall)     AS Halls,
       (SELECT COUNT(*) FROM dbo.Seat)     AS Seats,
       (SELECT COUNT(*) FROM dbo.[Session]) AS Sessions,
       (SELECT COUNT(*) FROM dbo.[User])   AS Users,
       (SELECT COUNT(*) FROM dbo.Ticket)   AS Tickets;
GO
