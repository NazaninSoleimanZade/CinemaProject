USE [cinema];
GO

-- =====================================================================
-- DANGER: this script DELETES ALL TABLES AND ALL DATA in the cinema DB
-- (users, tickets, everything). Run it ONLY when you want a clean start.
-- Normal order:  00_reset.sql  ->  01_schema.sql  ->  02_seed.sql
-- =====================================================================
IF OBJECT_ID(N'dbo.Ticket',        N'U') IS NOT NULL DROP TABLE dbo.Ticket;
IF OBJECT_ID(N'dbo.PaymentMethod', N'U') IS NOT NULL DROP TABLE dbo.PaymentMethod;
IF OBJECT_ID(N'dbo.Payment',       N'U') IS NOT NULL DROP TABLE dbo.Payment;
IF OBJECT_ID(N'dbo.MovieLanguage', N'U') IS NOT NULL DROP TABLE dbo.MovieLanguage;
IF OBJECT_ID(N'dbo.MovieActor',    N'U') IS NOT NULL DROP TABLE dbo.MovieActor;
IF OBJECT_ID(N'dbo.MovieGenre',    N'U') IS NOT NULL DROP TABLE dbo.MovieGenre;
IF OBJECT_ID(N'dbo.[Session]',     N'U') IS NOT NULL DROP TABLE dbo.[Session];
IF OBJECT_ID(N'dbo.Seat',          N'U') IS NOT NULL DROP TABLE dbo.Seat;
IF OBJECT_ID(N'dbo.Hall',          N'U') IS NOT NULL DROP TABLE dbo.Hall;
IF OBJECT_ID(N'dbo.[User]',        N'U') IS NOT NULL DROP TABLE dbo.[User];
IF OBJECT_ID(N'dbo.Movie',         N'U') IS NOT NULL DROP TABLE dbo.Movie;
IF OBJECT_ID(N'dbo.Cinema',        N'U') IS NOT NULL DROP TABLE dbo.Cinema;
GO
