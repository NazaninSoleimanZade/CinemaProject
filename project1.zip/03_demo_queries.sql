USE [cinema];
GO

-- Demo / report queries. Read-only: safe to run any time.

-- Lists the names of all tables in the current database
SELECT name FROM sys.tables;

-- Basic listings with ORDER BY
SELECT * FROM dbo.Cinema ORDER BY CinemaID;
SELECT * FROM dbo.Hall ORDER BY CinemaID, HallNumber;
SELECT * FROM dbo.Seat ORDER BY CinemaID, HallNumber, RowNo, SeatNo;
SELECT * FROM dbo.[Session] ORDER BY CinemaID, HallNumber, ShowDate, StartTime;
SELECT * FROM dbo.Payment;
SELECT * FROM dbo.PaymentMethod;
SELECT * FROM dbo.Ticket ORDER BY BuyDate DESC;

-- Subquery: all movies whose titles contain the word "The"
SELECT *
FROM dbo.Movie
WHERE FilmID IN (
    SELECT FilmID
    FROM dbo.Movie
    WHERE Title LIKE N'%The%'
);

-- INNER JOIN: movies and their genres
SELECT m.Title, g.Genre
FROM dbo.Movie AS m
INNER JOIN dbo.MovieGenre AS g ON m.FilmID = g.FilmID;

-- Basic user information (no password column)
SELECT Username, Role, FirstName
FROM dbo.[User];

-- Ticket details with session price and movie title
SELECT t.QRCode, t.Username, t.CinemaID, t.HallNumber, t.ShowDate, t.StartTime,
       t.RowNo, t.SeatNo, t.TicketStatus, s.Price, m.Title
FROM dbo.Ticket AS t
JOIN dbo.[Session] AS s
  ON s.CinemaID   = t.CinemaID
 AND s.HallNumber = t.HallNumber
 AND s.ShowDate   = t.ShowDate
 AND s.StartTime  = t.StartTime
JOIN dbo.Movie AS m ON m.FilmID = s.FilmID;

-- Movies with their sessions (date, time, hall, and price)
SELECT m.FilmID, m.Title,
       s.CinemaID, s.HallNumber, s.ShowDate, s.StartTime, s.EndTime, s.Price
FROM dbo.Movie AS m
JOIN dbo.[Session] AS s ON s.FilmID = m.FilmID
ORDER BY m.FilmID, s.ShowDate, s.StartTime;

-- Seats that are still free for one session (Failed tickets do not hold a seat)
DECLARE @CinemaID INT = 2, @HallNumber INT = 1,
        @ShowDate DATE = DATEADD(DAY, 1, CAST(GETDATE() AS DATE)),
        @StartTime TIME(0) = '18:00';

SELECT st.RowNo, st.SeatNo, st.SeatType
FROM dbo.Seat AS st
WHERE st.CinemaID = @CinemaID AND st.HallNumber = @HallNumber
  AND NOT EXISTS (
        SELECT 1 FROM dbo.Ticket AS t
        WHERE t.CinemaID = st.CinemaID AND t.HallNumber = st.HallNumber
          AND t.ShowDate = @ShowDate AND t.StartTime = @StartTime
          AND t.RowNo = st.RowNo AND t.SeatNo = st.SeatNo
          AND t.TicketStatus <> N'Failed')
ORDER BY st.RowNo, st.SeatNo;
GO
