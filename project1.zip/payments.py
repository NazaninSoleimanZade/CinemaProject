"""Simulated payment gateway (for a development / academic project).

IMPORTANT: nothing here talks to a bank or a real payment provider. The result of an
online payment is decided by a random number generator on the server. Never present
it as a real bank decision, and never store card numbers or CVVs.

How a payment moves (one payment attempt per ticket, Ticket.PaymentID -> Payment):

    Payment :  Pending --> Paid
                  \\-----> Failed

    Ticket  :  Reserved --(start_payment)--> Pending --(finish_payment)--> Paid
                                                  \\------------------------> Failed (seat released)
               Reserved --(mark_paid_cash, staff)--> Paid

Every function receives an open pyodbc connection and commits or rolls back by itself,
so the caller does not need to think about half-finished states.
"""
import os
import secrets
import uuid

from database import SESSION_STARTS_AT

# Reasons are stored in Payment.FailureReason. The SIMULATED_ prefix makes it obvious
# in the database that these are NOT decisions of a real bank.
FAILURE_REASONS = ('SIMULATED_DECLINE', 'SIMULATED_INSUFFICIENT_FUNDS', 'SIMULATED_TIMEOUT')

FAILURE_MESSAGES = {
    'SIMULATED_DECLINE': 'The simulated gateway declined this payment.',
    'SIMULATED_INSUFFICIENT_FUNDS': 'The simulated gateway reported insufficient funds.',
    'SIMULATED_TIMEOUT': 'The simulated gateway did not answer in time.',
    'PENDING_EXPIRED': 'The payment was not completed in time and was cancelled automatically.',
    'SEED_DATA': 'This is demo data from the seed script.',
}

DEFAULT_FAILURE_RATE = 0.15
DEFAULT_PENDING_TIMEOUT_MINUTES = 10


# ----------------------------------------------------------------- configuration
# Settings are read when needed (not at import time) so tests can change them.

def simulation_enabled():
    """Set PAYMENT_SIMULATION=0 to switch the online payment feature off."""
    return os.environ.get('PAYMENT_SIMULATION', '1') != '0'


def failure_rate():
    """Chance (0.0 - 1.0) that a simulated payment fails.

    PAYMENT_FAILURE_RATE sets it. The default (0.15) is only a demo setting that makes
    failures visible; it is NOT an estimate of how often real payments fail.
    Invalid values fall back to the default and the result is clamped to [0, 1].
    """
    try:
        rate = float(os.environ.get('PAYMENT_FAILURE_RATE', DEFAULT_FAILURE_RATE))
    except ValueError:
        return DEFAULT_FAILURE_RATE
    if rate != rate:                      # NaN
        return DEFAULT_FAILURE_RATE
    return min(max(rate, 0.0), 1.0)


def pending_timeout_minutes():
    try:
        minutes = int(os.environ.get('PAYMENT_PENDING_TIMEOUT_MINUTES', DEFAULT_PENDING_TIMEOUT_MINUTES))
    except ValueError:
        return DEFAULT_PENDING_TIMEOUT_MINUTES
    return minutes if minutes > 0 else DEFAULT_PENDING_TIMEOUT_MINUTES


def failure_message(reason):
    """Text for the user. Unknown reasons get a neutral sentence."""
    return FAILURE_MESSAGES.get(reason or '', 'The payment did not complete.')


def _new_reference(prefix):
    return prefix + uuid.uuid4().hex[:20].upper()


# ----------------------------------------------------------------- the simulation

def simulate_outcome(rng=None):
    """Decide the result of one payment. Returns ('Paid', None) or ('Failed', reason).

    `rng` can be any object with random() and choice(); tests pass a fake one.
    The result is decided here, on the server. Nothing from the browser is used.
    """
    rng = rng or secrets.SystemRandom()
    if rng.random() < failure_rate():
        return 'Failed', rng.choice(FAILURE_REASONS)
    return 'Paid', None


# ----------------------------------------------------------------- phase 1

def start_payment(conn, ticket_id, username):
    """Claim a Reserved ticket for an online payment.

    In ONE database transaction this creates a Pending payment (amount taken from the
    showtime's price in the database) and moves the ticket Reserved -> Pending.

    Returns (payment_id, reference), or None if the ticket cannot be paid now (not
    yours, not Reserved, already has a payment, or the showtime already started).

    Double clicks / two browser tabs: the final UPDATE only matches while the ticket is
    still Reserved with no payment. Exactly one request can win it; the other gets
    rowcount 0 and is rolled back (its Payment row disappears with the rollback).
    """
    cur = conn.cursor()
    cur.execute(f"""
        SELECT S.Price
        FROM Ticket T
        JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                        AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
        WHERE T.QRCode = ? AND T.Username = ?
          AND T.TicketStatus = 'Reserved' AND T.PaymentID IS NULL
          AND {SESSION_STARTS_AT} > GETDATE()
    """, (ticket_id, username))
    row = cur.fetchone()
    if row is None:
        conn.rollback()
        return None

    reference = _new_reference('SIM-')
    cur.execute("""
        INSERT INTO Payment (Amount, PaymentStatus, Reference)
        OUTPUT INSERTED.PaymentID
        VALUES (?, 'Pending', ?)
    """, (row[0], reference))
    payment_id = cur.fetchall()[0][0]   # read the whole result first

    cur.execute("""
        UPDATE Ticket SET TicketStatus = 'Pending', PaymentID = ?
        WHERE QRCode = ? AND Username = ?
          AND TicketStatus = 'Reserved' AND PaymentID IS NULL
    """, (payment_id, ticket_id, username))
    if cur.rowcount != 1:                 # somebody else claimed the ticket first
        conn.rollback()
        return None

    conn.commit()
    return payment_id, reference


# ----------------------------------------------------------------- phase 3

def finish_payment(conn, payment_id, ticket_id, outcome, reason=None):
    """Write the final result of Payment AND Ticket together, in one transaction.

    outcome is 'Paid' or 'Failed' (the same words are used for payment and ticket).
    A Failed ticket no longer holds the seat (see UX_Ticket_ActiveSeat).
    Raises RuntimeError (after rollback) if the payment or ticket is not Pending any
    more, e.g. because it was already finished or expired.
    """
    if outcome not in ('Paid', 'Failed'):
        raise ValueError(f'unknown outcome: {outcome!r}')

    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE Payment
            SET PaymentStatus = ?, CompletedDate = SYSDATETIME(), FailureReason = ?
            WHERE PaymentID = ? AND PaymentStatus = 'Pending'
        """, (outcome, reason if outcome == 'Failed' else None, payment_id))
        if cur.rowcount != 1:
            raise RuntimeError('payment is not Pending any more')

        cur.execute("""
            UPDATE Ticket SET TicketStatus = ?
            WHERE QRCode = ? AND PaymentID = ? AND TicketStatus = 'Pending'
        """, (outcome, ticket_id, payment_id))
        if cur.rowcount != 1:
            raise RuntimeError('ticket is not Pending any more')

        if outcome == 'Paid':
            cur.execute("INSERT INTO PaymentMethod (PaymentID, MethodType) VALUES (?, 'SimulatedGateway')",
                        (payment_id,))
        conn.commit()
    except Exception:
        conn.rollback()
        raise


# ----------------------------------------------------------------- cashier

def mark_paid_cash(conn, ticket_id):
    """Staff confirms that a customer paid cash at the cinema (Reserved -> Paid).

    Returns the payment reference, or None if the ticket is not Reserved any more.
    """
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT S.Price
            FROM Ticket T
            JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                            AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
            WHERE T.QRCode = ? AND T.TicketStatus = 'Reserved' AND T.PaymentID IS NULL
        """, (ticket_id,))
        row = cur.fetchone()
        if row is None:
            conn.rollback()
            return None

        reference = _new_reference('CASH-')
        cur.execute("""
            INSERT INTO Payment (Amount, PaymentStatus, Reference, CompletedDate)
            OUTPUT INSERTED.PaymentID
            VALUES (?, 'Paid', ?, SYSDATETIME())
        """, (row[0], reference))
        payment_id = cur.fetchall()[0][0]   # read the whole result first

        cur.execute("""
            UPDATE Ticket SET TicketStatus = 'Paid', PaymentID = ?
            WHERE QRCode = ? AND TicketStatus = 'Reserved' AND PaymentID IS NULL
        """, (payment_id, ticket_id))
        if cur.rowcount != 1:
            conn.rollback()
            return None

        cur.execute("INSERT INTO PaymentMethod (PaymentID, MethodType) VALUES (?, 'Cash')", (payment_id,))
        conn.commit()
        return reference
    except Exception:
        conn.rollback()
        raise


# ----------------------------------------------------------------- clean-up

def expire_stale_pending(conn, minutes=None):
    """Cancel payments that stayed Pending too long (e.g. the server crashed between
    phase 1 and phase 3). The payment becomes Failed and the ticket Failed, which
    releases the seat. Returns the number of payments expired."""
    minutes = minutes or pending_timeout_minutes()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE Payment
            SET PaymentStatus = 'Failed', CompletedDate = SYSDATETIME(),
                FailureReason = 'PENDING_EXPIRED'
            WHERE PaymentStatus = 'Pending'
              AND PaymentDate < DATEADD(MINUTE, ?, SYSDATETIME())
        """, (-minutes,))
        expired = cur.rowcount
        cur.execute("""
            UPDATE T SET T.TicketStatus = 'Failed'
            FROM Ticket T
            JOIN Payment P ON P.PaymentID = T.PaymentID
            WHERE T.TicketStatus = 'Pending' AND P.PaymentStatus = 'Failed'
        """)
        conn.commit()
        return expired
    except Exception:
        conn.rollback()
        raise
