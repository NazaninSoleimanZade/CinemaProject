"""Standalone database check. Run:  python test_db.py

Uses the same connection settings as the app (database.py: server, driver, database),
so there is only ONE place to change them (see DB_SERVER / DB_DRIVER / DB_NAME in README.md).
If this prints a red cross, the problem is ODBC / SQL Server, not the Flask code.
"""
from werkzeug.security import generate_password_hash

from database import get_db_connection, conn_str


def test_connection():
    print("Connection string:", conn_str)
    conn = get_db_connection()
    if not conn:
        print("❌ Could not connect to the database (see the error printed above)")
        return False

    try:
        cursor = conn.cursor()
        for label, table in (("Users", "[User]"), ("Movies", "Movie"),
                             ("Cinemas", "Cinema"), ("Sessions", "[Session]"),
                             ("Seats", "Seat"), ("Tickets", "Ticket")):
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            print(f"✅ {label} in database: {cursor.fetchone()[0]}")
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Query failed: {e}")
        conn.close()
        return False


def test_user_creation():
    """Insert a throw-away user, then delete it again."""
    conn = get_db_connection()
    if not conn:
        return False

    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO [User] (Username, Password, Role, Email, FirstName, LastName)
            VALUES (?, ?, 'Customer', NULL, 'Test', 'User')
        """, ("test_user_123", generate_password_hash("secret123")))
        conn.commit()
        print("✅ Test user created")

        cursor.execute("DELETE FROM [User] WHERE Username = ?", ("test_user_123",))
        conn.commit()
        print("✅ Test user removed")
        conn.close()
        return True
    except Exception as e:
        print(f"❌ User creation test failed: {e}")
        conn.close()
        return False


if __name__ == "__main__":
    if test_connection():
        test_user_creation()
