"""Database settings and helpers.

This is the ONLY place that knows how to reach SQL Server (server, driver, database
name). app.py, payments.py and test_db.py all use it, so there is one place to change
the connection (see DB_SERVER / DB_DRIVER / DB_NAME in README.md).
"""
import logging
import os
from contextlib import contextmanager

import pyodbc

log = logging.getLogger(__name__)


# --- CONFIGURATION ---
# Change the server with the DB_SERVER environment variable if "localhost" is not right,
# e.g.  set DB_SERVER=.\SQLEXPRESS
def _pick_driver():
    """Use ODBC Driver 18 or 17 for SQL Server, whichever is installed."""
    wanted = os.environ.get('DB_DRIVER')
    if wanted:
        return wanted
    installed = pyodbc.drivers()
    for name in ('ODBC Driver 18 for SQL Server', 'ODBC Driver 17 for SQL Server'):
        if name in installed:
            return name
    return 'ODBC Driver 17 for SQL Server'


conn_str = (
    f"Driver={{{_pick_driver()}}};"
    f"Server={os.environ.get('DB_SERVER', 'localhost')};"
    f"Database={os.environ.get('DB_NAME', 'cinema')};"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)

# SQL fragment: the moment a showtime starts. It needs the [Session] table to be
# aliased as S. (DATE cast to DATETIME is midnight; TIME cast to DATETIME is
# 1900-01-01 + the time, so adding them gives "date + time".)
SESSION_STARTS_AT = "(CAST(S.ShowDate AS DATETIME) + CAST(S.StartTime AS DATETIME))"


class DatabaseUnavailable(Exception):
    """Raised when we cannot connect to SQL Server (handled once, in app.py)."""


def get_db_connection():
    """Open a connection, or return None (and log why) if that is not possible."""
    try:
        return pyodbc.connect(conn_str)
    except pyodbc.Error as e:
        log.error("Database connection error (pyodbc): %s", e)
        return None
    except Exception as e:
        log.error("Database connection error (general): %s", e)
        return None


@contextmanager
def db():
    """Use it like:  with db() as conn: ...

    * commits when the block finishes normally,
    * rolls back if the block raises an error (the error is re-raised),
    * ALWAYS closes the connection,
    * raises DatabaseUnavailable if the connection cannot be opened.
    """
    conn = get_db_connection()
    if conn is None:
        raise DatabaseUnavailable()
    try:
        yield conn
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:      # the connection itself may be broken
            pass
        raise
    finally:
        conn.close()
