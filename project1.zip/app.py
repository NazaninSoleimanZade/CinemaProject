import csv
import io
import logging
import math
import os
import re
import secrets
import time
import uuid
from datetime import date, datetime
from functools import wraps

import pyodbc
from flask import (Flask, Response, abort, flash, jsonify,
                   redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import payments
# conn_str and get_db_connection are re-exported so `from app import conn_str` still works.
from database import (SESSION_STARTS_AT, DatabaseUnavailable, conn_str,  # noqa: F401
                      db, get_db_connection)

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

# The key that signs the session cookie (it also protects the user's role!).
# Set your own with the SECRET_KEY environment variable. If it is missing, a random key
# is generated at start-up: safe, but everybody is logged out whenever the app restarts.
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
# Set SESSION_COOKIE_SECURE=1 when the site is served over HTTPS.
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE') == '1'

# Debug helpers (e.g. /debug/db-test) are only active when you start the app with
# the environment variable FLASK_DEBUG=1  (Windows cmd:  set FLASK_DEBUG=1)
DEBUG = os.environ.get('FLASK_DEBUG') == '1'

# Roles allowed to open the staff dashboard
STAFF_ROLES = ('Staff', 'Admin')


def _env_int(name, default):
    """Positive integer from an environment variable, or the default."""
    try:
        value = int(os.environ.get(name, default))
    except ValueError:
        return default
    return value if value > 0 else default


# A customer may hold at most this many unpaid (Reserved/Pending) tickets for
# showtimes that have not started yet.  Raised to 20 to match the multi-seat
# booking cap (MAX_SEATS = 20 on the frontend).
MAX_OPEN_RESERVATIONS = _env_int('MAX_OPEN_RESERVATIONS', 20)
# Maximum seats allowed in a single booking request (mirrors MAX_SEATS in JS).
MAX_SEATS_PER_BOOKING = _env_int('MAX_SEATS_PER_BOOKING', 20)
LOGIN_MAX_FAILURES = _env_int('LOGIN_MAX_FAILURES', 5)
LOGIN_WINDOW_SECONDS = _env_int('LOGIN_WINDOW_SECONDS', 300)
DASHBOARD_PAGE_SIZE = 50

# Column sizes of the [User] table (see database/01_schema.sql)
MAX_USERNAME, MAX_FIRST_NAME, MAX_LAST_NAME, MAX_EMAIL = 50, 50, 80, 120
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


# ---------------------------------------------------------------- CSRF protection
# CSRF = another website makes the visitor's browser send a POST to our site (the
# browser attaches the login cookie automatically). To stop that, every form contains a
# secret token that only pages served by our site know.

def get_csrf_token():
    token = session.get('_csrf_token')
    if not token:
        token = secrets.token_hex(16)
        session['_csrf_token'] = token
    return token


@app.before_request
def csrf_protect():
    if request.method in ('GET', 'HEAD', 'OPTIONS'):
        return
    sent = request.form.get('csrf_token', '')
    expected = session.get('_csrf_token', '')
    if not expected or not secrets.compare_digest(sent.encode('utf-8'), expected.encode('utf-8')):
        abort(400)


# ---------------------------------------------------------------- templates helpers

@app.context_processor
def inject_template_helpers():
    """Makes these names available in every template."""
    return {
        'is_staff': session.get('role') in STAFF_ROLES,
        'csrf_token': get_csrf_token,
        'payment_enabled': payments.simulation_enabled(),
    }


@app.template_filter('toman')
def toman_filter(value):
    """150000.00 -> '150,000 Toman'"""
    if value is None:
        return 'N/A'
    return f"{float(value):,.0f} Toman"


@app.template_filter('hhmm')
def hhmm_filter(value):
    """18:00:00 -> '18:00'"""
    return value.strftime('%H:%M') if hasattr(value, 'strftime') else str(value)


# ---------------------------------------------------------------- error pages

@app.errorhandler(DatabaseUnavailable)
def handle_database_unavailable(error):
    if request.method == 'POST':
        flash('Database connection error. Please try again later.', 'error')
        return redirect(url_for('index'))
    return render_template('error.html', title='Service unavailable',
                           message='The database cannot be reached right now. '
                                   'Please try again in a few minutes.'), 503


@app.errorhandler(400)
def handle_bad_request(error):
    return render_template('error.html', title='Request not accepted',
                           message='The form is invalid or has expired. '
                                   'Go back, reload the page and try again.'), 400


@app.errorhandler(404)
def handle_not_found(error):
    return render_template('error.html', title='Page not found',
                           message='We could not find what you were looking for.'), 404


@app.errorhandler(500)
def handle_server_error(error):
    return render_template('error.html', title='Something went wrong',
                           message='An unexpected error happened. It has been logged.'), 500


# ---------------------------------------------------------------- access control

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if 'username' not in session:
            flash('Please log in to continue.', 'error')
            return redirect(url_for('login_page'))
        return view(*args, **kwargs)
    return wrapped


def staff_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get('role') not in STAFF_ROLES:
            flash('Access denied. Staff access required.', 'error')
            return redirect(url_for('index'))
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------- small helpers

def seat_exists(cursor, cinema_id, hall_number, row_no, seat_no):
    """True if this physical seat exists in the hall."""
    cursor.execute("""
        SELECT COUNT(*) FROM Seat
        WHERE CinemaID = ? AND HallNumber = ? AND RowNo = ? AND SeatNo = ?
    """, (cinema_id, hall_number, row_no, seat_no))
    return cursor.fetchone()[0] > 0


def seat_is_free(cursor, cinema_id, hall_number, show_date, start_time, row_no, seat_no):
    """A seat is taken by any ticket that is not Failed (same rule as the
    UX_Ticket_ActiveSeat unique index in the database)."""
    cursor.execute("""
        SELECT COUNT(*) FROM Ticket
        WHERE CinemaID = ? AND HallNumber = ? AND ShowDate = ?
          AND StartTime = ? AND RowNo = ? AND SeatNo = ?
          AND TicketStatus <> 'Failed'
    """, (cinema_id, hall_number, show_date, start_time, row_no, seat_no))
    return cursor.fetchone()[0] == 0


def _valid_date(text):
    try:
        datetime.strptime(text or '', '%Y-%m-%d')
        return True
    except ValueError:
        return False


def _valid_time(text):
    for fmt in ('%H:%M:%S', '%H:%M'):
        try:
            datetime.strptime(text or '', fmt)
            return True
        except ValueError:
            pass
    return False


_last_sweep = None


def maybe_sweep(conn):
    """Cancel payments that stayed Pending too long. Runs at most once a minute and
    only when somebody looks at tickets / payments (no background job needed)."""
    global _last_sweep
    now = time.monotonic()
    if _last_sweep is not None and now - _last_sweep < 60:
        return
    _last_sweep = now
    try:
        expired = payments.expire_stale_pending(conn)
        if expired:
            app.logger.info('Expired %s stale pending payment(s)', expired)
    except pyodbc.Error:
        app.logger.exception('Could not expire stale pending payments')


# Brute-force protection for /login: remembers recent failures per (IP, username) in
# memory. It resets when the app restarts and is not shared between several processes.
_failed_logins = {}


def _recent_failures(key):
    cutoff = time.monotonic() - LOGIN_WINDOW_SECONDS
    recent = [t for t in _failed_logins.get(key, []) if t > cutoff]
    if recent:
        _failed_logins[key] = recent
    else:
        _failed_logins.pop(key, None)
    return recent


def _ticket_select(extra_where=''):
    """SQL used by the ticket page (one ticket with everything the page shows)."""
    return f"""
        SELECT T.QRCode AS TicketID, T.Username, T.RowNo, T.SeatNo, T.TicketStatus,
               T.BuyDate, M.Title, C.CinemaName, T.HallNumber, T.ShowDate, T.StartTime,
               S.Price, P.Reference AS PaymentRef, P.PaymentStatus,
               CASE WHEN {SESSION_STARTS_AT} > GETDATE() THEN 1 ELSE 0 END AS IsFuture
        FROM Ticket T
        JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                        AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
        JOIN Movie M ON M.FilmID = S.FilmID
        JOIN Cinema C ON C.CinemaID = T.CinemaID
        LEFT JOIN Payment P ON P.PaymentID = T.PaymentID
        WHERE T.QRCode = ? {extra_where}
    """


# ---------------------------------------------------------------- public pages

@app.route('/')
def index():
    search_query = request.args.get('search', '')
    genre_filter = request.args.get('genre', '')

    with db() as conn:
        cursor = conn.cursor()

        # Get all genres for filter dropdown
        cursor.execute("SELECT DISTINCT Genre FROM MovieGenre ORDER BY Genre")
        genres = [row[0] for row in cursor.fetchall()]

        # Build dynamic query based on filters (only fixed text is added to the SQL;
        # the user's values always travel as ? parameters)
        sql = """
            SELECT M.FilmID, M.Title, M.AgeRating, M.DurationMin, M.Director,
                   STRING_AGG(G.Genre, ', ') AS Genre
            FROM Movie M
            LEFT JOIN MovieGenre G ON M.FilmID = G.FilmID
        """

        conditions = []
        params = []

        if search_query:
            conditions.append("M.Title LIKE ?")
            params.append('%' + search_query + '%')

        if genre_filter:
            conditions.append("EXISTS (SELECT 1 FROM MovieGenre MG WHERE MG.FilmID = M.FilmID AND MG.Genre = ?)")
            params.append(genre_filter)

        if conditions:
            sql += " WHERE " + " AND ".join(conditions)

        sql += " GROUP BY M.FilmID, M.Title, M.AgeRating, M.DurationMin, M.Director ORDER BY M.Title"

        cursor.execute(sql, params)
        movies = cursor.fetchall()

    return render_template('index.html', movies=movies, genres=genres,
                           current_search=search_query, current_genre=genre_filter)


@app.route('/login_page')
def login_page():
    return render_template('login.html')


@app.route('/register_page')
def register_page():
    return render_template('register.html')


# ---------------------------------------------------------------- accounts

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm_password', '')
    email = request.form.get('email', '').strip()
    first_name = request.form.get('first_name', '').strip()
    last_name = request.form.get('last_name', '').strip()

    # Self-registration ALWAYS creates a Customer. Staff/Admin/Operator accounts
    # are created by an administrator directly in the database.
    role = 'Customer'

    # Basic validation
    if not username or not password or not first_name or not last_name:
        flash('Please fill in all required fields.', 'error')
        return redirect(url_for('register_page'))

    if len(username) < 3 or any(ch.isspace() for ch in username):
        flash('Username must be at least 3 characters and contain no spaces.', 'error')
        return redirect(url_for('register_page'))

    if (len(username) > MAX_USERNAME or len(first_name) > MAX_FIRST_NAME
            or len(last_name) > MAX_LAST_NAME or len(email) > MAX_EMAIL):
        flash('One of the fields is too long '
              f'(username {MAX_USERNAME}, first name {MAX_FIRST_NAME}, '
              f'last name {MAX_LAST_NAME}, email {MAX_EMAIL} characters at most).', 'error')
        return redirect(url_for('register_page'))

    if email and not EMAIL_RE.match(email):
        flash('Please enter a valid email address.', 'error')
        return redirect(url_for('register_page'))

    if password != confirm_password:
        flash('Passwords do not match.', 'error')
        return redirect(url_for('register_page'))

    if len(password) < 6:
        flash('Password must be at least 6 characters long.', 'error')
        return redirect(url_for('register_page'))

    try:
        with db() as conn:
            cursor = conn.cursor()

            # Check if username already exists
            cursor.execute("SELECT Username FROM [User] WHERE Username = ?", (username,))
            if cursor.fetchone():
                flash('Username already exists. Please choose a different one.', 'error')
                return redirect(url_for('register_page'))

            # Check if email already exists (if provided)
            if email:
                cursor.execute("SELECT Username FROM [User] WHERE Email = ?", (email,))
                if cursor.fetchone():
                    flash('Email already registered. Please use a different email.', 'error')
                    return redirect(url_for('register_page'))

            # Insert new user (a missing email is stored as NULL, not as '')
            hashed_pw = generate_password_hash(password)
            cursor.execute("""
                INSERT INTO [User] (Username, Password, Role, Email, FirstName, LastName)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (username, hashed_pw, role, email or None, first_name, last_name))
    except pyodbc.IntegrityError:
        # Someone registered the same username/email between our check and the INSERT
        app.logger.warning('Registration integrity error', exc_info=True)
        flash('Username or email already exists. Please try different values.', 'error')
        return redirect(url_for('register_page'))
    except pyodbc.Error:
        app.logger.exception('Registration database error')
        flash('Database error occurred. Please try again later.', 'error')
        return redirect(url_for('register_page'))

    flash('Registration successful! Please log in.', 'success')
    return redirect(url_for('login_page'))


@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')

    if not username or not password:
        flash('Please enter both username and password.', 'error')
        return redirect(url_for('login_page'))

    key = f"{request.remote_addr}|{username.lower()}"
    if len(_recent_failures(key)) >= LOGIN_MAX_FAILURES:
        flash('Too many failed login attempts. Please wait a few minutes and try again.', 'error')
        return redirect(url_for('login_page'))

    with db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT Username, Password, Role, FirstName FROM [User] WHERE Username = ?",
                       (username,))
        user = cursor.fetchone()

    if user and check_password_hash(user[1], password):
        _failed_logins.pop(key, None)
        session.clear()                       # start from a clean session
        session['username'] = user[0]         # the name exactly as stored in the database
        session['role'] = user[2]
        session['first_name'] = user[3]
        flash(f'Welcome back, {user[3]}!', 'success')
        return redirect(url_for('index'))

    _failed_logins.setdefault(key, []).append(time.monotonic())
    flash('Invalid username or password.', 'error')
    return redirect(url_for('login_page'))


@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))


# ---------------------------------------------------------------- booking

@app.route('/get_showtimes/<int:film_id>')
def get_showtimes(film_id):
    """API endpoint to get upcoming showtimes for a movie"""
    try:
        with db() as conn:
            cursor = conn.cursor()
            cursor.execute(f"""
                SELECT S.CinemaID, C.CinemaName, S.HallNumber, S.ShowDate, S.StartTime, S.Price
                FROM [Session] S
                JOIN Cinema C ON S.CinemaID = C.CinemaID
                WHERE S.FilmID = ? AND {SESSION_STARTS_AT} > GETDATE()
                ORDER BY S.ShowDate, S.StartTime
            """, (film_id,))
            rows = cursor.fetchall()
    except DatabaseUnavailable:
        return jsonify({'error': 'Database connection failed'}), 503

    showtimes = []
    for row in rows:
        showtimes.append({
            'cinema_id': row[0],
            'cinema_name': row[1],
            'hall_number': row[2],
            'show_date': row[3].strftime('%Y-%m-%d'),
            'start_time': str(row[4]),
            'price': float(row[5])
        })
    return jsonify(showtimes)


@app.route('/get_seats/<int:cinema_id>/<int:hall_number>/<show_date>/<start_time>')
@login_required
def get_seats(cinema_id, hall_number, show_date, start_time):
    """Return seat layout + occupancy for a showtime. Read-only, parameterized."""
    if not _valid_date(show_date) or not _valid_time(start_time):
        return jsonify({'error': 'Invalid date or time'}), 400
    try:
        with db() as conn:
            cursor = conn.cursor()
            # All physical seats in this hall, ordered for display
            cursor.execute("""
                SELECT RowNo, SeatNo
                FROM Seat
                WHERE CinemaID = ? AND HallNumber = ?
                ORDER BY RowNo, SeatNo
            """, (cinema_id, hall_number))
            all_seats = cursor.fetchall()

            # Seats already taken for this showtime (any status except Failed)
            cursor.execute("""
                SELECT RowNo, SeatNo
                FROM Ticket
                WHERE CinemaID = ? AND HallNumber = ?
                  AND ShowDate = ? AND StartTime = ?
                  AND TicketStatus <> 'Failed'
            """, (cinema_id, hall_number, show_date, start_time))
            taken = {(r[0], r[1]) for r in cursor.fetchall()}

    except DatabaseUnavailable:
        return jsonify({'error': 'Database connection failed'}), 503

    seats = [
        {'row': s[0], 'seat': s[1],
         'status': 'taken' if (s[0], s[1]) in taken else 'free'}
        for s in all_seats
    ]
    return jsonify(seats)


@app.route('/book', methods=['POST'])
@login_required
def book_ticket():
    """Book one or more seats in a single atomic transaction.

    Expected form fields:
      seats_json   – JSON list of {row, seat} objects, e.g. [{"row":1,"seat":3},…]
      cinema_id, hall_number, show_date, start_time  – injected by the JS submit handler
    """
    import json as _json

    # ── 1. Parse and validate seat list ──────────────────────────────
    seats_raw = request.form.get('seats_json', '').strip()
    if not seats_raw:
        flash('Please select at least one seat before booking.', 'error')
        return redirect(url_for('index'))

    try:
        seat_list = _json.loads(seats_raw)
    except (ValueError, TypeError):
        flash('Invalid seat data. Please select your seats again.', 'error')
        return redirect(url_for('index'))

    if not isinstance(seat_list, list) or not seat_list:
        flash('Please select at least one seat.', 'error')
        return redirect(url_for('index'))

    if len(seat_list) > MAX_SEATS_PER_BOOKING:
        flash(f'You can select a maximum of {MAX_SEATS_PER_BOOKING} seats per booking.', 'error')
        return redirect(url_for('index'))

    seat_pairs = []
    seen = set()
    for item in seat_list:
        try:
            r = int(item['row'])
            s = int(item['seat'])
        except (KeyError, TypeError, ValueError):
            flash('Seat data is malformed. Please select your seats again.', 'error')
            return redirect(url_for('index'))
        if (r, s) in seen:
            flash(f'Duplicate seat Row {r} Seat {s} in your selection.', 'error')
            return redirect(url_for('index'))
        seen.add((r, s))
        seat_pairs.append((r, s))

    # ── 2. Validate showtime fields ───────────────────────────────────
    cinema_id   = request.form.get('cinema_id',   type=int)
    hall_number = request.form.get('hall_number', type=int)
    show_date   = request.form.get('show_date')
    start_time  = request.form.get('start_time')

    if not all([cinema_id, hall_number, show_date, start_time]):
        missing = [f for f, v in [('cinema_id', cinema_id), ('hall_number', hall_number),
                                   ('show_date', show_date), ('start_time', start_time)] if not v]
        flash(f'Booking details incomplete. Missing: {", ".join(missing)}', 'error')
        return redirect(url_for('index'))

    if not _valid_date(show_date) or not _valid_time(start_time):
        flash('The selected showtime is not valid. Please choose it again.', 'error')
        return redirect(url_for('index'))

    username   = session['username']
    booked_ids = []   # QRCode values of inserted tickets

    try:
        with db() as conn:
            cursor = conn.cursor()

            # ── 3. Confirm showtime exists and has not started ────────
            cursor.execute(f"""
                SELECT C.CinemaName, M.Title, S.Price
                FROM [Session] S
                JOIN Cinema C ON C.CinemaID = S.CinemaID
                JOIN Movie M ON M.FilmID = S.FilmID
                WHERE S.CinemaID = ? AND S.HallNumber = ? AND S.ShowDate = ? AND S.StartTime = ?
                  AND {SESSION_STARTS_AT} > GETDATE()
            """, (cinema_id, hall_number, show_date, start_time))
            if not cursor.fetchone():
                flash('The selected showtime does not exist or has already started. '
                      'Please choose another one.', 'error')
                return redirect(url_for('index'))

            # ── 4. Validate every seat before inserting any ───────────
            for row_no, seat_no in seat_pairs:
                if not seat_exists(cursor, cinema_id, hall_number, row_no, seat_no):
                    flash(f'Row {row_no} Seat {seat_no} does not exist in this hall.', 'error')
                    return redirect(url_for('index'))
                if not seat_is_free(cursor, cinema_id, hall_number, show_date, start_time,
                                    row_no, seat_no):
                    flash(f'Row {row_no} Seat {seat_no} is already taken. '
                          'Please go back and choose different seats.', 'error')
                    return redirect(url_for('index'))

            # ── 5. Open-reservation cap ───────────────────────────────
            cursor.execute(f"""
                SELECT COUNT(*)
                FROM Ticket T
                JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                                AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
                WHERE T.Username = ? AND T.TicketStatus IN ('Reserved', 'Pending')
                  AND {SESSION_STARTS_AT} > GETDATE()
            """, (username,))
            current_open = cursor.fetchone()[0]
            if current_open + len(seat_pairs) > MAX_OPEN_RESERVATIONS:
                available_slots = MAX_OPEN_RESERVATIONS - current_open
                flash(
                    f'You already hold {current_open} unpaid reservation(s). '
                    f'You can add at most {available_slots} more seat(s) at this time.',
                    'error'
                )
                return redirect(url_for('my_tickets'))

            # ── 6. Insert one Ticket per seat (all in one transaction) ─
            for row_no, seat_no in seat_pairs:
                ticket_id = str(uuid.uuid4())
                cursor.execute("""
                    INSERT INTO Ticket
                        (QRCode, Username, CinemaID, HallNumber, ShowDate, StartTime,
                         RowNo, SeatNo, TicketStatus)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Reserved')
                """, (ticket_id, username, cinema_id, hall_number,
                      show_date, start_time, row_no, seat_no))
                booked_ids.append(ticket_id)
            # db() commits here when the with-block exits normally

    except pyodbc.IntegrityError:
        # UX_Ticket_ActiveSeat fired — a concurrent request took one of the seats
        app.logger.warning('Booking integrity error (race condition)', exc_info=True)
        flash('One or more seats were just taken by someone else. '
              'Please go back and choose different seats.', 'error')
        return redirect(url_for('index'))
    except pyodbc.Error:
        app.logger.exception('Booking database error')
        flash('A database error occurred. Please try again later.', 'error')
        return redirect(url_for('index'))

    # ── 7. Post/Redirect/Get ──────────────────────────────────────────
    n = len(booked_ids)
    flash(f'{n} ticket{"s" if n != 1 else ""} booked successfully!', 'success')

    if n == 1:
        # Single seat → deep-link to that ticket (original behaviour)
        return redirect(url_for('ticket_page', ticket_id=booked_ids[0]))

    # Multiple seats → show the full list on My Tickets
    return redirect(url_for('my_tickets'))


# ---------------------------------------------------------------- tickets

@app.route('/ticket/<ticket_id>')
@login_required
def ticket_page(ticket_id):
    owner_filter = None if session.get('role') in STAFF_ROLES else session['username']
    with db() as conn:
        maybe_sweep(conn)
        cursor = conn.cursor()
        if owner_filter is None:
            cursor.execute(_ticket_select(), (ticket_id,))
        else:
            cursor.execute(_ticket_select('AND T.Username = ?'), (ticket_id, owner_filter))
        ticket = cursor.fetchone()

    if not ticket:
        abort(404)       # also used for other people's tickets: do not reveal they exist

    is_reserved = ticket.TicketStatus == 'Reserved'
    is_owner = ticket.Username == session['username']
    ticket_json = {
        'movie': ticket.Title, 'username': ticket.Username, 'cinema': ticket.CinemaName,
        'hall': ticket.HallNumber, 'seat': f'Row {ticket.RowNo}, Seat {ticket.SeatNo}',
        'show_date': ticket.ShowDate.strftime('%Y-%m-%d'), 'start_time': hhmm_filter(ticket.StartTime),
        'price': float(ticket.Price), 'ticket_id': ticket.TicketID, 'status': ticket.TicketStatus,
    }
    return render_template(
        'ticket.html', ticket=ticket, ticket_json=ticket_json,
        can_pay=is_owner and is_reserved and bool(ticket.IsFuture) and payments.simulation_enabled(),
        can_cancel=is_owner and is_reserved,
        pending_minutes=payments.pending_timeout_minutes())


@app.route('/ticket/<ticket_id>/cancel', methods=['POST'])
@login_required
def cancel_ticket(ticket_id):
    """The owner gives up an unpaid reservation (the seat becomes free again)."""
    with db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE Ticket SET TicketStatus = 'Failed'
            WHERE QRCode = ? AND Username = ? AND TicketStatus = 'Reserved' AND PaymentID IS NULL
        """, (ticket_id, session['username']))
        cancelled = cursor.rowcount == 1

    if cancelled:
        flash('Your reservation was cancelled and the seat was released.', 'success')
    else:
        flash('This ticket cannot be cancelled (it is not an unpaid reservation of yours).', 'error')
    return redirect(url_for('ticket_page', ticket_id=ticket_id))


@app.route('/my_tickets')
@login_required
def my_tickets():
    with db() as conn:
        maybe_sweep(conn)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT T.QRCode AS TicketID, T.RowNo, T.SeatNo, T.TicketStatus, T.BuyDate,
                   M.Title, C.CinemaName, T.HallNumber, T.ShowDate, T.StartTime
            FROM Ticket T
            JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                            AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
            JOIN Movie M ON M.FilmID = S.FilmID
            JOIN Cinema C ON C.CinemaID = T.CinemaID
            WHERE T.Username = ?
            ORDER BY T.ShowDate DESC, T.StartTime DESC, T.BuyDate DESC
        """, (session['username'],))
        tickets = cursor.fetchall()
    return render_template('my_tickets.html', tickets=tickets)


# ---------------------------------------------------------------- payments (simulation)

@app.route('/pay/<ticket_id>', methods=['POST'])
@login_required
def pay(ticket_id):
    """Pay for a Reserved ticket with the SIMULATED gateway.

    The browser sends nothing but the ticket id (and the CSRF token): the amount comes
    from the database and the result is decided on the server (payments.py)."""
    if not payments.simulation_enabled():
        flash('Online payment is currently switched off.', 'error')
        return redirect(url_for('ticket_page', ticket_id=ticket_id))

    try:
        with db() as conn:
            maybe_sweep(conn)

            # Phase 1: claim the ticket (Reserved -> Pending) and create a Pending payment
            started = payments.start_payment(conn, ticket_id, session['username'])
            if started is None:
                flash('This ticket cannot be paid now: it is not yours, not an unpaid '
                      'reservation, already being paid, or the show has started.', 'error')
                return redirect(url_for('ticket_page', ticket_id=ticket_id))
            payment_id, reference = started

            # Phase 2: the simulated decision (random, server side)
            outcome, reason = payments.simulate_outcome()

            # Phase 3: save the result of Payment and Ticket together
            payments.finish_payment(conn, payment_id, ticket_id, outcome, reason)
    except DatabaseUnavailable:
        raise
    except Exception:
        # A simulated FAILURE is a normal result and does not end up here. This is a real
        # technical error. If it happened after phase 1 the ticket stays Pending and is
        # cancelled automatically after PAYMENT_PENDING_TIMEOUT_MINUTES.
        app.logger.exception('Payment processing failed for ticket %s', ticket_id)
        flash('Something went wrong while processing the payment. Check the ticket status '
              'below; an unfinished payment is cancelled automatically after a few minutes.', 'error')
        return redirect(url_for('ticket_page', ticket_id=ticket_id))

    return redirect(url_for('payment_result', reference=reference))


@app.route('/payment/<reference>')
@login_required
def payment_result(reference):
    owner_filter = '' if session.get('role') in STAFF_ROLES else 'AND T.Username = ?'
    params = [reference] if not owner_filter else [reference, session['username']]
    with db() as conn:
        maybe_sweep(conn)
        cursor = conn.cursor()
        cursor.execute(f"""
            SELECT P.Reference, P.PaymentStatus, P.Amount, P.PaymentDate, P.CompletedDate,
                   P.FailureReason,
                   (SELECT TOP 1 PM.MethodType FROM PaymentMethod PM
                    WHERE PM.PaymentID = P.PaymentID ORDER BY PM.MethodType) AS Method,
                   T.QRCode AS TicketID, T.TicketStatus, T.RowNo, T.SeatNo, T.HallNumber,
                   T.ShowDate, T.StartTime, M.Title, C.CinemaName
            FROM Payment P
            JOIN Ticket T ON T.PaymentID = P.PaymentID
            JOIN [Session] S ON S.CinemaID = T.CinemaID AND S.HallNumber = T.HallNumber
                            AND S.ShowDate = T.ShowDate AND S.StartTime = T.StartTime
            JOIN Movie M ON M.FilmID = S.FilmID
            JOIN Cinema C ON C.CinemaID = T.CinemaID
            WHERE P.Reference = ? {owner_filter}
        """, params)
        payment = cursor.fetchone()

    if not payment:
        abort(404)
    return render_template('payment_result.html', payment=payment,
                           failure_text=payments.failure_message(payment.FailureReason),
                           pending_minutes=payments.pending_timeout_minutes())


# ---------------------------------------------------------------- staff dashboard

@app.route('/dashboard')
@staff_required
def dashboard():
    page = max(1, request.args.get('page', 1, type=int))

    with db() as conn:
        maybe_sweep(conn)
        cursor = conn.cursor()

        # Summary statistics (COALESCE: SUM returns NULL on an empty table)
        cursor.execute("""
            SELECT
                COUNT(*) AS total_tickets,
                COALESCE(SUM(CASE WHEN TicketStatus = 'Paid'     THEN 1 ELSE 0 END), 0) AS paid_tickets,
                COALESCE(SUM(CASE WHEN TicketStatus = 'Reserved' THEN 1 ELSE 0 END), 0) AS reserved_tickets,
                COALESCE(SUM(CASE WHEN TicketStatus = 'Pending'  THEN 1 ELSE 0 END), 0) AS pending_tickets
            FROM Ticket
        """)
        stats = cursor.fetchone()

        pages = max(1, math.ceil(stats.total_tickets / DASHBOARD_PAGE_SIZE))
        page = min(page, pages)

        # The template reads columns by NAME (ticket.Title ...), so the order of this
        # SELECT does not matter any more.
        cursor.execute("""
            SELECT T.QRCode AS TicketID, T.Username, U.FirstName, U.LastName, T.RowNo, T.SeatNo,
                   T.TicketStatus, T.BuyDate, M.Title, C.CinemaName, T.ShowDate, T.StartTime,
                   P.Reference AS PaymentRef
            FROM Ticket T
            JOIN [User] U ON T.Username = U.Username
            JOIN [Session] S ON T.CinemaID = S.CinemaID AND T.HallNumber = S.HallNumber
                             AND T.ShowDate = S.ShowDate AND T.StartTime = S.StartTime
            JOIN Movie M ON S.FilmID = M.FilmID
            JOIN Cinema C ON T.CinemaID = C.CinemaID
            LEFT JOIN Payment P ON P.PaymentID = T.PaymentID
            ORDER BY T.BuyDate DESC, T.QRCode
            OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
        """, ((page - 1) * DASHBOARD_PAGE_SIZE, DASHBOARD_PAGE_SIZE))
        tickets = cursor.fetchall()

    return render_template('dashboard.html', tickets=tickets, stats=stats, page=page, pages=pages)


def _csv_safe(value):
    """Spreadsheet programs run text that starts with = + - @ as a formula. A leading
    apostrophe makes it plain text (protects the staff member who opens the file)."""
    text = '' if value is None else str(value)
    return "'" + text if text[:1] in ('=', '+', '-', '@', '\t', '\r') else text


@app.route('/dashboard/export.csv')
@staff_required
def export_bookings_csv():
    """All bookings (not only the current page) with the FULL ticket numbers."""
    with db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT T.QRCode AS TicketID, T.Username, U.FirstName, U.LastName, M.Title,
                   C.CinemaName, T.HallNumber, T.ShowDate, T.StartTime, T.RowNo, T.SeatNo,
                   T.TicketStatus, P.Reference AS PaymentRef, P.PaymentStatus, T.BuyDate
            FROM Ticket T
            JOIN [User] U ON T.Username = U.Username
            JOIN [Session] S ON T.CinemaID = S.CinemaID AND T.HallNumber = S.HallNumber
                             AND T.ShowDate = S.ShowDate AND T.StartTime = S.StartTime
            JOIN Movie M ON S.FilmID = M.FilmID
            JOIN Cinema C ON T.CinemaID = C.CinemaID
            LEFT JOIN Payment P ON P.PaymentID = T.PaymentID
            ORDER BY T.BuyDate DESC, T.QRCode
        """)
        rows = cursor.fetchall()

    out = io.StringIO()
    writer = csv.writer(out, quoting=csv.QUOTE_ALL)
    writer.writerow(['Ticket ID', 'Username', 'First name', 'Last name', 'Movie', 'Cinema', 'Hall',
                     'Show date', 'Start time', 'Row', 'Seat', 'Ticket status', 'Payment reference',
                     'Payment status', 'Booked at'])
    for r in rows:
        writer.writerow([_csv_safe(v) for v in (
            r.TicketID, r.Username, r.FirstName, r.LastName, r.Title, r.CinemaName, r.HallNumber,
            r.ShowDate, hhmm_filter(r.StartTime), r.RowNo, r.SeatNo, r.TicketStatus, r.PaymentRef,
            r.PaymentStatus, r.BuyDate.strftime('%Y-%m-%d %H:%M:%S') if r.BuyDate else '')])

    # The BOM (\ufeff) makes Excel read Persian / non-English text correctly.
    filename = f"cinema_bookings_{date.today().isoformat()}.csv"
    return Response('\ufeff' + out.getvalue(), mimetype='text/csv; charset=utf-8',
                    headers={'Content-Disposition': f'attachment; filename={filename}'})


@app.route('/staff/ticket/<ticket_id>/mark_paid', methods=['POST'])
@staff_required
def staff_mark_paid(ticket_id):
    """The cashier confirms a cash payment at the counter (Reserved -> Paid)."""
    with db() as conn:
        reference = payments.mark_paid_cash(conn, ticket_id)

    if reference:
        flash(f'Ticket marked as paid (cash). Payment reference: {reference}', 'success')
    else:
        flash('This ticket is not an unpaid reservation any more, so nothing was changed.', 'error')
    return redirect(url_for('dashboard', page=request.form.get('page', 1, type=int)))


# ---------------------------------------------------------------- debug

@app.route('/debug/db-test')
def debug_db_test():
    """Debug route to test database connection (only with FLASK_DEBUG=1)"""
    if not DEBUG:
        return "Debug mode only (start the app with FLASK_DEBUG=1)", 403

    conn = get_db_connection()
    if not conn:
        return "Database connection failed"

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM [User]")
        user_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM Movie")
        movie_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM Cinema")
        cinema_count = cursor.fetchone()[0]

        return f"""
        Database Connection: SUCCESS<br>
        Users: {user_count}<br>
        Movies: {movie_count}<br>
        Cinemas: {cinema_count}<br>
        """
    except Exception as e:
        return f"Database query failed: {e}"
    finally:
        conn.close()


if __name__ == '__main__':
    app.run(debug=DEBUG)
